

# Goal

- To be able to retrieve data from an API call that allows me to reduce the time to retrieve data

---

# Problem

- Allows me to get eBay sales data quickly. But also, in general learn about APIs so that I can create information out of the data generally. 

---

# Success Criteria

- When I am able to not only successfully retrieve sales data from my store, but ensure the data is properly formatted and integral

---

# Progress

COMPLETED

---

# Challenges

Lack of range in terms of time, and therefore, needing to run multiple times to get more then 3 months worth of data

---

# Lessons Learned

How easy the starting code is.

---

# Future Improvements

Learning of specific API endpoints, testing, and more.

---


# References



# Related Notes
