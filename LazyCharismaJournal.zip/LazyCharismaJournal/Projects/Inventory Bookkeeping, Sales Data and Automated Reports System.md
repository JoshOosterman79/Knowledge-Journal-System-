
### As of 2026-08-07

[Link To Project](C:\Users\pokem\OneDrive\Desktop\my_project_folder\projects\my_programming_projects\Projects\ebay_orders_projects_v1)



Title of Project: Inventory Bookkeeping and Basic Sales System

Link:

Goal: 

To be able to track and record inventory from purchases using Microsoft Excel and *Queries and Connections*. From inventory we also use an API that allows us to get sales data from eBay. Along with other tables that track sales, we would now have generative sales data that tracks specific inventory by shipment. The project also would track shipping, supplies, COGS, and other expenses to generate a Income Statement, Cash Flow Statement, a debt sheet, and a payables book as well. 

We also want this to be automated and light-weight as possible, while also ensuring full integrity and accuracy of the data


Current Status:
considered good enough with revisions/refactoring to do


Research:
- Microsoft Excel
- Python (mainly API's and Pandas)
- Databases and maintaining

Problems:
- Inconsistent Data entries
- Adaptability
- Design


Self-Reflection
- Instead of running every X day, can we just perform an auto-run on specific days?


Systems:
- Bookkeeping System
- eBay Sales API







