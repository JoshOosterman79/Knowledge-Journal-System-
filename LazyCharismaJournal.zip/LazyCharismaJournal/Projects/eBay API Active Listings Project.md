

Date: 2026-08-12 

Title of Project: eBay API Active Listings Project


Summary: In this project, I have learnt the fundamentals of API requests of XML content. I learnt what the headers and body would I use to properly call the eBay active listings API endpoint. From there, I used a Root to access the ElementalTree (the whole document or data) and to access the elements. Which I further went deeper using For Loops to retrieve the data I need to create a Active Listings Database. I then inserted the data into SQLite3 to create a SQL database, from there I would call that database to convert to a Dataframe for me to filter out PreOrders using SKU's.

Goal: To learn/re-learn how to use an API call to retrieve in our case active listings from our own eBay Store. The goal here is rely less on code to help and more from reading documentation to understand what is required. 


Current Status:
Finished

Tasks:
- Simply output/print active listings header
- Return all necessary data
- Covert data in table/database
- Convert date variables to proper dates
- Convert pandas table to SQL table
- Properly read SQL table
- Add Error-handling
- Structure Proper Pagination / For Loop to ensure all Listings are there
- Filter by SKU / make transferable to entire Active Listings vs Specific SKU's



Research:
Python/API
XML


Problems:

Lessons:

Related Systems:
Database Management

Resources:
https://developer.ebay.com/Devzone/XML/docs/Reference/ebay/GetMyeBaySelling.html


Code
```
import requests
import xml.etree.ElementTree as ET
import csv
from datetime import datetime, timezone
from config import access_token, app_name, cert_name, dev_name
import pandas as pd
import sqlite3
from read_db import read_db
import json

conn = sqlite3.connect("data/activelistings.db")
date_now = datetime.now(tz=timezone.utc)

# eBay XML namespace
NS = {'e': 'urn:ebay:apis:eBLBaseComponents'}

def parse_ebay_datetime(dt_str):

        if not dt_str:
            return None

        formats = [
            "%Y-%m-%dT%H:%M:%S.%fZ",
            "%Y-%m-%dT%H:%M:%SZ",
        ]

        for fmt in formats:
            try:
                return datetime.strptime(dt_str, fmt).replace(tzinfo=timezone.utc)
            except ValueError:
                continue

        return None

def get_active_listings():
    pages_number = 1
    active_listings = []

    url = 'https://api.ebay.com/ws/api.dll'

    
    while True:

        
        HEADERS = {
            "X-EBAY-API-CALL-NAME": "GetMyeBaySelling",
            "X-EBAY-API-SITEID": "0",
            "X-EBAY-API-COMPATIBILITY-LEVEL": "967",
            "X-EBAY-API-DEV-NAME": dev_name,
            "X-EBAY-API-APP-NAME": app_name,
            "X-EBAY-API-CERT-NAME": cert_name,
            "X-EBAY-API-REQUEST-ENCODING": "XML",
            "Content-Type": "text/xml"
        }

        body = f"""<?xml version="1.0" encoding="utf-8"?>
        <GetMyeBaySellingRequest xmlns="urn:ebay:apis:eBLBaseComponents">
        <RequesterCredentials>
            <eBayAuthToken>{access_token}</eBayAuthToken>
        </RequesterCredentials>
        <ActiveList>
        <Include>True</Include>
            <Sort>TimeLeft</Sort>
            <Pagination>
            <EntriesPerPage>100</EntriesPerPage>
            <PageNumber>{pages_number}</PageNumber>
            </Pagination>
        </ActiveList>
        </GetMyeBaySellingRequest> """


        response = requests.post(url, headers=HEADERS, data=body)
        response.raise_for_status()


        root = ET.fromstring(response.text)

        errors = root.findall('.//e:Errors', NS)
        if errors:
            for err in errors:
                code = err.findtext('e:ErrorCode', default='UNKNOWN', namespaces=NS)
                msg = err.findtext('e:ShortMessage', default='No message', namespaces=NS)
                print(f"eBay API Error {code}: {msg}")
                break


        pages_elem = root.find('.//e:PaginationResult/e:TotalNumberOfPages', NS)
        number_pages_elem = int(pages_elem.text)
        if pages_elem is None:
            print("Could not find total pages in the response.")
            print(response.text)


        for activelist in root.findall('e:ActiveList', NS):
            for child in activelist.find('e:ItemArray', NS):

                ItemId = child.findtext('e:ItemID', default="N/A", namespaces=NS)
                title = child.findtext('e:Title', default="N/A", namespaces=NS)
                sku = child.findtext('e:SKU', default="N/A", namespaces=NS)
                buy_now_price = child.findtext('e:BuyItNowPrice', default="N/A", namespaces=NS)
                quantity = child.findtext('e:Quantity', default="N/A", namespaces=NS)
                listing_type = child.findtext('e:ListingType', default="N/A", namespaces=NS)
                start_time = child.findtext('e:ListingDetails/e:StartTime', default='', namespaces=NS)
                
                str_time_left = parse_ebay_datetime(start_time)
                listing_duration = date_now - str_time_left
                listing_duration = listing_duration.days

                active_listings.append({
                    "ItemId": ItemId,
                    "Title": title,
                    "SKU": sku,
                    "Price": buy_now_price,
                    "Quantity": quantity,
                    "Start Time": str_time_left.date(),
                    "Listing Duration": listing_duration,
                    "Listing Type": listing_type,
                })

        print(f"Retrieving from Page {pages_number} of {number_pages_elem}")
        if pages_number >= number_pages_elem:
            break
        pages_number +=1
    return active_listings


####


columns = ([
            "ItemId",
            "Title",
            "SKU",
            "Price",
            "Quantity",
            "Start Time",
            "Listing Duration",
            "Listing Type"
        ])

active_listings = get_active_listings()

active_listings_tb = pd.DataFrame(active_listings, columns=columns, index=None)

active_listings_sql = list(active_listings_tb.itertuples(index=False, name=None))

cursor = conn.cursor()


cursor.executemany("""
INSERT OR REPLACE INTO activelistings
(itemId, title, sku, price, quantity, startTime, listingDuration, listingType)
VALUES(?,?,?,?,?,?,?,?)
""", active_listings_sql)


conn.commit()
conn.close()

df_read = read_db()


# To Gather 2026-PREORDER Solely
df_preorder_sorted = df_read[df_read["sku"] == "2026-PREORDER"]
print(f"\n Reading {(df_preorder_sorted["title"].count())} entries from activelistings table \nSummary:\n {df_preorder_sorted.head()}")


print(f"\n Reading {(df_read["title"].count())} entries from activelistings table \nSummary:\n {df_read.head()}")



timestamp = {
    "Active Listings": str(date_now)
}

with open("timestamps.json", "w") as f:
    json.dump(timestamp, f, indent=3)


```


