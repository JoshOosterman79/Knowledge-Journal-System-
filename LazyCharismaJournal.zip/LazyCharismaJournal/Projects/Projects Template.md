

# In this Folder, we fill out information of projects that we would like to build and source material such as the programs languages you learn, the functions, algorithms, and general coding practice as well.


Title of Project:

Goal:


Current Status:

Tasks:


Research:

Problems:

Lessons:

Related Systems: