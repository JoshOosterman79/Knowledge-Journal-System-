

Date: 2026-08-10

Title of Project: Consignment Portfolio - Databases

Goal: To be able to add new listings to this database/project to maintain and monitor. This database will also allow me to perform data analytics in the future. This project also allows me to learn the skills to build reliable, scalable databases.

Current Status: Beginning

Tasks:
- Pull All current portfolio active listings on eBay
- Pull Sourcing Data
- Pull Analytical / Traffic Data

- Merge

Research:

SQLITE
Python
Excel

Problems:



Lessons:



Related Systems:
Database Management


Footnotes:
