
Title of Project: Consignment Portfolio - Traffic & Analytical Data

Goal:
- Now with sourcing and active listings databases. We can now take that specific listing and draw analytics from it. Here would be the table to make decisions, whether to remove as active listings, sell through auctions, or anticipate future sales to further scale in terms of facebook listings, multiple stocks, special photos, and all


Current Status:
Implementation

Tasks:
API Call of Active Listings
merge with listings_watcher table (the merged table of sourcing/active listings)
Workflow the rest of code



Research:
Analyticals/Data
SQLlite3
Pandas
Decision-Making

Problems:

Lessons:

Related Systems: