


Title of Project: Excel Inventory Input

Goal:
- to overhaul the SKU/sourcing by minimizing the number of tables made depending on the account, and also ensure data integrity using SQL and data validation. We also want to simplify the inventory input process

Current Status:
- Beginning


Tasks:
- Create Excel Table for Data Entries of Inventory
- Add Known entries to this table
- table -> database
- fix how timestamp works
- customs/shipping builder -> table -> database
- try to connect entries from inventory db to db of customs/shipping




- Using Macros. Build a function that automatically adds to the table





Research:
- Macros/Automation for Excel



Problems:
- We would need to address proper shipping expense compared to the shipping costs I charge, and also a flat shipping fee





Lessons:


Related Systems: