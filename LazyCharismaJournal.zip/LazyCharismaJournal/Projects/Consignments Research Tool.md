
- First we need to get access to the traffic report details. We can manually download that but with limitations. So we use API

- we now have a more robust Active Listings API. which now includes 

ItemID	SKU	Title	QuantityListed	QuantitySoldLifetime	QuantityAvailable	Price	Currency	ListingType	DateListed	EndTime	DaysLive	TrafficStartDate	TrafficEndDate	TrafficRecordReturned	TOTAL_IMPRESSION_TOTAL	LISTING_IMPRESSION_SEARCH_RESULTS_PAGE	LISTING_IMPRESSION_STORE	LISTING_VIEWS_TOTAL	LISTING_VIEWS_SOURCE_SEARCH_RESULTS_PAGE	LISTING_VIEWS_SOURCE_STORE	LISTING_VIEWS_SOURCE_DIRECT	LISTING_VIEWS_SOURCE_OFF_EBAY	LISTING_VIEWS_SOURCE_OTHER_EBAY	CLICK_THROUGH_RATE	ClickThroughRatePercent	TRANSACTION	SALES_CONVERSION_RATE	SalesConversionRatePercent

- We could also add Offer Count and Watchers as well

2026-07-17 - we added now watchers/offers


