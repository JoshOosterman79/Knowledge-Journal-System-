
Date: 2026-08-10

Title of Project: Consignment Portfolio Project

Goal:
- To create a portfolio of listings of consignment that allows me to maximize cash flow and sales while minimizing using capital until purchase. This project allows me to add, remove, monitor, and create decisions of listings. I want this project to be transferable to other items and investments, and also a program worth selling to clients as a service as you are essentially building your own algorithm.

Current Status: Beginning Stages

Tasks:
- Phase 1 — Database
- Phase 2 — Data pipeline
- Phase 3 — Analysis
- Phase 4 — Finance
- Phase 5 — Decision science
- Phase 6 — Automation

Research:
XML




Problems:





Lessons:
- SQLite
- Python/Pandas
- API
- Database
- Excel
- XML

Related Systems:
- Research Tool
- Database Management

Tasks:
- Manual: Select X amount of listings and update their price

