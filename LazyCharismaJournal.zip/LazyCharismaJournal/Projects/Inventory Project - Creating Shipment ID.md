


Title of Project: Shipment Id Project

Goal: 
- to build unique shipment ID's in a matter that is clean, and easy to create. The goal is to be able to link to multiple inventory purchases into 1 shipment. The goal is to track the shipment data and to be able to merge them with the appropriate inventory that would be in that shipment.


Current Status:
- Implementation

Tasks:
- 

Research:
- Excel
- SQLLite3
- Panadas


Problems:

Lessons:

Related Systems: