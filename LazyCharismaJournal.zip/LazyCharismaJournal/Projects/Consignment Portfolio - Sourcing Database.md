
Title of Project: Consignment Portfolio - Databases - Sourcing 

Goal:
- To be able to maintain a database of all the entries I create when creating listings for Pre-order. The objective here is to simply and maintain and database of the prices I sourced at, along with the condition, the timestamps, and perhaps my own analysis/decision on what I want to do with such entry X. We also create our own calculations/projections of what it could look like if I sold at X price.


Current Status:
Finished (with refractor oppurtunities)


Tasks:
Review Routine of getting entries
Created Database Schema/Columns
Use Python/Excel for Calculations
create database
Create Sales SKU

merge with active listing database
Track Active Listings based on the SKU

Research:
Internal SKU's

Footnotes:
We can use whether an active listing is returned via SKU as the status on whether it is listed or not


Problems:
- In terms of efficiency, it would make more sense to have one calculator / builder rather then 2 separate ones (one for consignment and one for regular inventory). This also causes conflictions and confusions if we decide to use 2 calculators. So instead we categorize the type of inventory, create one giant DB, and then specify/filter from there
- We should keep track of non-active listings



Lessons:
- Even if you don't end up listing a card, we should still input the data


Related Systems:


Steps Made:

