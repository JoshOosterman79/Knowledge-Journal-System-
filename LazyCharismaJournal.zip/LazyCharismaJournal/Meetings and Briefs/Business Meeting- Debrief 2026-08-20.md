
- Evergreen Cards

How can I balance selling at profits, and also using consignments and charging as service

Concern: what if a card crashes in price i sell at a buyer

Can we pull Data from Facebook?


Sure. Okay. Here's a clean debrief from our session. The user reviewed a mid-August sales slowdown and identified likely seasonality tied to the upcoming September Pokemon release rather than business failure. The conversation re-framed the business as multiple cash flow engines, pre-orders, consignments, owned inventory, and as an experiment in shifting partially from resale profits to charging for sourcing and handling as a service. Customer relationships were discussed with an emphasis on transparency and proactive value rather than reacting to market drops. Facebook was positioned as a data source, not just a sales channel, and for the remainder of August, the focus is on system building, inventory prep, and customer outreach, rather than forcing short-term sales.


