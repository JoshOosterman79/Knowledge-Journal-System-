
# The purpose of this Vault is to establish knowledge and being able to retrieve, read, review, document, and record my learnings building a intelligence system and further hone my skills in multiple fields.


### **Archives**

- Previous entries that are no longer needed on-demand, but suited to revisit and recall and past learnings to help with future knowledge
### **Projects**
- the Projects that continue to improve any of the systems and also my skills & knowledge in specific fields. Meant to also share on Github and LinkedIn

### **References**
- Any references from external sources that help with building the knowledge journal

### **Review & Reflections**
- Features periodic entries that allows me to review previous goals, experiments, and failures to learn from.

### **Skills & Knowledge**
- Any field of learning that I enter that builds new skills and knowledge. This could include learning more about programming languages, finances, or statistical equations that help with the business.

### **Systems**
- The never-ending systems of the business that will always continue to get better

### **Dashboard**
- A quick overview of objectives, goals, deadlines.





