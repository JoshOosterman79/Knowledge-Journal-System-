# This template can be used to make all notes in this folder familiar and to not overthink and waste time

# Goal

Why am I building this?

---

# Problem

What problem does it solve?

---

# Success Criteria

How do I know it's finished?

---

# Progress

Current status

---

# Challenges

What's blocking me?

---

# Lessons Learned

What surprised me?

---

# Future Improvements

What would Version 2 look like?

---

# References
[[Orders - Basic API parameters]]

# Related Notes

