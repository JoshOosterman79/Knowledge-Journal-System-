
Dimensions - 6x6x4
Weight - ~410