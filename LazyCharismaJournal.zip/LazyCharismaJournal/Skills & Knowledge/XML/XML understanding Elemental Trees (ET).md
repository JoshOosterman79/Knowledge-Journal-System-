
- When we describe a document in XML, we are referring a Tree.
- When we a describing a element within an XML, we are referring to a Node. 

- We we talk about the XML document as a whole, we are discussing on a Elemental Tree level.
- When we talk about the XML element within a document, we are discussing on a Elemental Level.

Recall The Set-up
