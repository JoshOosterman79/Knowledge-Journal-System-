
# Recall what you know of API's.

- You call a specific API endpoint depending on what data you want to request and retrieve
- You use a URL to access that endpoint
- You have headers, usually to verify yourself and to input what type of content you would like to return (in our previous cases a JSON return, but here, we return XML)
- You had params, which determined the sample of data you wanted, like within a time range, or categories.


So we Have the URL endpoint

```
url = 'https://api.ebay.com/ws/api.dll'
```




```
HEADERS = {

    "X-EBAY-API-CALL-NAME": "GetMyeBaySelling",

    "X-EBAY-API-SITEID": "0",

    "X-EBAY-API-COMPATIBILITY-LEVEL": "967",

    "X-EBAY-API-DEV-NAME": dev_name,

    "X-EBAY-API-APP-NAME": app_name,

    "X-EBAY-API-CERT-NAME": cert_name,

    "X-EBAY-API-REQUEST-ENCODING": "XML",

    "Content-Type": "text/xml"

}
```

- the headers template for API calls using XML and "GetMyeBaySelling API". This is the API that allows me to access active/sold listings for my store


In this case, we have the following as a parameter

```
body = f"""<?xml version="1.0" encoding="utf-8"?>

<GetMyeBaySellingRequest xmlns="urn:ebay:apis:eBLBaseComponents">

  <RequesterCredentials>

    <eBayAuthToken>{access_token}</eBayAuthToken>

  </RequesterCredentials>

  <ActiveList>

  <Include>True</Include>

    <Sort>TimeLeft</Sort>

    <Pagination>

      <EntriesPerPage>3</EntriesPerPage>

      <PageNumber>1</PageNumber>

    </Pagination>

  </ActiveList>

</GetMyeBaySellingRequest> """
```


Here we have
- Our credentials
- Active Listings or not
- Pagination, meaning how many entries are we getting per page




Resources
https://developer.ebay.com/Devzone/XML/docs/Reference/ebay/GetMyeBaySelling.html#Input