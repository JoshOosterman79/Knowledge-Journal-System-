
We can actually use a mix of SQL language and also Pandas to make this a very simple process. Here we use a simple read_sql() function to convert to a dataframe, which make this easy to read, and export to a csv file


```
import sqlite3

import pandas as pd

  

conn = sqlite3.connect("data/activelistings.db")

  
  

query = """

    SELECT *

    FROM activelistings

"""

  

df = pd.read_sql(query, conn)

conn.close()  

print(df.head())
```

