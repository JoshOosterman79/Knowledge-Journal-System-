
Source: https://dbschema.com/blog/sqlite/constraints/

Primary Key - "uniquely identifies each row"

Unique - "Disallows duplicate values"

For your business, or database in general when it comes to sourcing inventory

- Have an entry be unique **focuses on Primary key.** This ensures that a transaction that you have is recorded.
- Have a specific inventory item focused on **UNIQUE**. This allows you to view a specific card or a collection of similar items (for example a bulk lot of a certain pokemon set), and also specific cards (e.g. Pikachu 001/001 this set)

