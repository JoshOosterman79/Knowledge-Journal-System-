
- To implement a proper database, we can use SQLLite3 to ensure data integrity

- we can start off creating the database that we will use for the orders


```
import sqlite3

conn = sqlite3.connect("data/orders.db")

cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS orders (
    order_id TEXT PRIMARY KEY,
    sku TEXT,
    quantity INTEGER,
    sale_price REAL
)
""")

conn.commit()
conn.close()

print("Database created")
```

To create database, we must
- create a connection file
- Be able to write into the database using cursor
- Creating a table and adding the columns
- committing and closing the database afterwards

We can start off with mock data to get the hang of it

```
import sqlite3

  

conn = sqlite3.connect("data/orders.db")

  

orders = (

    ["0001", "Charizard", 1, 29.99],

    ["0002", "Pikachu", 2, 19.99]

)

cursor = conn.cursor()

  

cursor.executemany("""

    INSERT OR REPLACE INTO orders

    (order_id, sku, quantity, order_price)

    VALUES(?,?,?,?)  

""", orders)

conn.commit()

conn.close()

  

print("Orders have been added to the Database")
```

Again we
- Have/create the data of orders
- create connection
- insert or replace into the database the orders
- commit/close

And now to view the mock data we entered into the database

```
import sqlite3
import pandas as pd

conn = sqlite3.connect("data/orders.db")

query = """
SELECT *
FROM orders
"""

df = pd.read_sql(query, conn)

print(df)

conn.close()
```

- So for viewing, we connect, create the Query, we use pandas to read the sql file, and we print the results

Debugging Notes:

Here we try to put json data in sqlite3


```
[{

    "orderid": "Pikachu",

    "sku": "0001",

    "quantity": 2,

    "order_price": 24.99

}]
```


```
orders = pd.read_json("data/mock_orders.json")
```

```
sqlite3.ProgrammingError: Incorrect number of bindings supplied. The current statement uses 4, and there are 7 supplied.
```

- So whats going on?

- We notice the program splits Pikachu into just the letters to total length 7, so therefore whatever the type is, the sql function is not able to read it properly. So we need to ensure, the DataFrame is converted to a Type that is readable

SOLUTION: Before Adding to the database, we convert to list using. values.tolist()

```
orders = orders.values.tolist()
```

Alternatively (and according to AI, more clean/efficient)
```
orders = list(orders.itertuples(index=False, name=None))
```

In this way, we don't mismatch values to different columns accordingly 



