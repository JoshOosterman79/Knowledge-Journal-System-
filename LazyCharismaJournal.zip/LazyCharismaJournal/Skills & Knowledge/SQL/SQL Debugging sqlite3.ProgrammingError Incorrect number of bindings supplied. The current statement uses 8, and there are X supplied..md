
```
 active_listings.append({

            "ItemId": ItemId,

            "Title": title,

            "SKU": sku,

            "Price": buy_now_price,

            "Quantity": quantity,

            "Start Time": str_time_left.date(),

            "Listing Duration": listing_duration,

            "Listing Type": listing_type,

        })

  
  

columns = ([

            "ItemId",

            "Title",

            "SKU",

            "Price",

            "Quantity",

            "Start Time",

            "Listing Duration",

            "Listing Type"

        ])

  

active_listings_tb = pd.DataFrame(active_listings, columns=columns, index=None)

print(active_listings)

  

cursor = conn.cursor()

  

cursor.executemany("""

INSERT OR REPLACE INTO activelistings

(itemId, title, sku, price, quantity, startTime, listingDuration, listingType)

VALUES(?,?,?,?,?,?,?,?)

""", active_listings_tb)

  

conn.commit()

conn.close()
```

We Get the following Errors

```
sqlite3.ProgrammingError: Incorrect number of bindings supplied. The current statement uses 8, and there are 6 supplied.
```


