
Here we have a code that generates a csv file successfully but we get duplicate headers

```
  

conn = sqlite3.connect("data/sourcingpurchases.db")

  

def read_db():

    conn = sqlite3.connect("data/sourcingpurchases.db")

  
  

    query = f"""

        SELECT *

        FROM sourcingpurchases

    """

  

    df = pd.read_sql(query, conn)

  

    conn.close()

  

    return df

  
  

current_folder = Path(__file__).parent

print(current_folder)

  

projects_folder = current_folder.parent

print(projects_folder)

  

excel_path = projects_folder / "inventory_book_macros.xlsm"

  

df = pd.read_excel(excel_path, sheet_name="beta_ICB_table", index_col=False)

  

sourcing_purchases_table = list(df.itertuples(index=False, name=None))

  

conn.executemany("""

INSERT OR REPLACE INTO sourcingpurchases

(title, ProductId, snkrDunkRating, investmentType, purchasePrice, sellingPrice, planFee, quantity, totalPurchaseCost, customsCost, flatShippingCost, totalImportCost, totalGrossProfit, grossProfitPER, ebayVariableFee, ebayFixedFee, ebayPromoFee, totaleBayFee, suppliesExpense, shippingExpenses, totalExpenses, netProfit, netProfitPER, waiveImportCost, waiveEbayFees, discountRate, discountRatePER, prePurchase, waiveCustoms, cardShow)

VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)

""", sourcing_purchases_table)

  

conn.commit()

conn.close()

  
  
  

columns = [

"Title",

"Product ID",

"SNKRDunk Rating",

"Investment Type",

"Purchase Price",

"Selling Price",

"Plan Fee",

"Quantity",

"Total Purchase Cost",

"Customs Cost",

"Flat Shipping Cost",

"Total Import Cost",

"Total Gross Profit",

"Gross Profit %",

"eBay Variable Fee",

"eBay Fixed Fee",

"eBay Promo Fee",

"Total eBay Fees",

"Supplies Expense",

"Shipping Expenses",

"Total Expenses",

"Net Profit",

"Net Profit %",

"Waive Import Costs",

"Waive eBay Fees",

"Discount Rate",

"Discount Rate ",

"Pre Purchased?",

"Waive Customs",

"Card Show"

]

  

# read_db_sourcing.to_csv("inventory_table.csv", index=False)
```

#output

```
Table Headers
Tables Headers again 
all Entries
....
....
...
```

Hint: We are gathering from two different sources (Excel and SQLite), why exactly do we get duplicate column headers


