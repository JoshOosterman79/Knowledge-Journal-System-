Resource: https://sqlite.org/lang_upsert.html
Code: get_sourcing_purchasing_data
Project: Inventory / Consignment Builder project
Description of Project: database integrity of entries of inventory purchases.

"UPSERT is a clause added to [INSERT](https://sqlite.org/lang_insert.html) that causes the INSERT to behave as an [UPDATE](https://sqlite.org/lang_update.html) or a no-op if the INSERT would violate a uniqueness constraint. UPSERT is not standard SQL. UPSERT in SQLite follows the syntax established by PostgreSQL, with generalizations."

We Have the following table
```
Title	id	entryId	SNKRDunk Rating	investmentType	Purchase Price	Selling Price	Plan Fee	Quantity	Total Purchase Cost	Customs Cost	Flat Shipping Cost	Total Import Cost	Total Gross Profit	Gross Profit %	eBay Variable Fee	eBay Fixed Fee	eBay Promo Fee	Total eBay Fees	Supplies Expense	Shipping Expenses	Total Expenses	Net Profit	Net Profit %	Waive Import Costs	Waive eBay Fees	Discount Rate	Discount Rate 	Pre Purchased?	Waive Customs	Card Show

```

entryId is unique, and Id is incremental and the primary key. Here we want to ensure that on multiple runs, these two columns don't change. But what we noticed using a simple INSERT into sql, the ID changes every time and increments. 

So How does Upsert work?


```
INSERT OR REPLACE INTO sourcingpurchases
(title, id, entryId, snkrDunkRating, investmentType, purchasePrice, sellingPrice, planFee, quantity, totalPurchaseCost, customsCost, flatShippingCost, totalImportCost, totalGrossProfit, grossProfitPER, ebayVariableFee, ebayFixedFee, ebayPromoFee, totaleBayFee, suppliesExpense, shippingExpenses, totalExpenses, netProfit, netProfitPER, waiveImportCost, waiveEbayFees, discountRate, discountRatePER, prePurchase, waiveCustoms, cardShow)
VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
ON CONFLICT(entryId)
DO UPDATE SET
    title = excluded.title,
    snkrDunkRating = excluded.snkrDunkRating,
    investmentType = excluded.investmentType,
    
    ...
    
    """, sourcing_purchasing_table
```

Upsert is as followed

- INSERT
- CONFLICT
- UPDATE

Logically

- "Insert only if entryId is new and is unique, if not new, let's only update that entry, and change these field values by using excluded."

Here we have the following entry

```
Mega Darkrai ex 114/081		E009	B	Consignment	 $236.08 	 $4.20 

```

# keep in mind the selling price, 4.20 is simply an error needing changing later on. 

With this error we want to change it into $300, the current selling price

So we make that entry update

```
Mega Darkrai ex 114/081		E009	B	Consignment	 $236.08 	 $300 
```

Insert into the table, run the program and you will noticed within the SQL database, it changes as well !



