
- what is the best practice when implementing future projects/database designs

