- "A variable that represents a ListObject collection"

ListObject
- 
