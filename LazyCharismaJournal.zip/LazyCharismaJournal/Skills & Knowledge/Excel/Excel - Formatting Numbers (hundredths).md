

Say we want numbers in the following format

001
002
...
100
101
...

