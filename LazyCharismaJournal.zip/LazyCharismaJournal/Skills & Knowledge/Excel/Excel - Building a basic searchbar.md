```
=FILTER(inventory[title],ISNUMBER(SEARCH(A5,inventory[title])),"No Result")

```

- WE have 3 functions/parts to look at

