
What is a macro?
- A macro is a set of actions, usually to automate repetitive tasks. Macros can also be edited afterwards

We actually started using a Macro by Going to the Developer Tab, and Recording the Macro, what we did was

- from the macro inventory book, created an entry from the Inventory Calculator Builder. From there we copied the entry into the ICB (inventory calculator builder database). If we go to the developer mode, and into the VBA modules, we see that the code looks like this

```
Sub add_inventory_entry_to_table()
'
' add_inventory_entry_to_table Macro
' entries in the inventory calculator builder would be added to the beta icb Table
'
' Keyboard Shortcut: Ctrl+i
'
    ActiveWindow.SmallScroll Down:=11
    Range("inventory_entry_tb").Select
    Selection.Copy
    Sheets("beta_ICB_table").Select
    Range("icb_tb[Title]").Select
    Selection.PasteSpecial Paste:=xlPasteValues, Operation:=xlNone, SkipBlanks _
        :=False, Transpose:=False
End Sub

```

