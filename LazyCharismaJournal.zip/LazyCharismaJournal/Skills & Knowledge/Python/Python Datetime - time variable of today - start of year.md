
Here we have the following variable

```
LOOKBACK_DAYS = 180
```

Here we would like to turn this into something dynamic like getting the days starting from today to all the days it has been from the beginning of the year. In this way, we ensure all data dates back to the year to the present


