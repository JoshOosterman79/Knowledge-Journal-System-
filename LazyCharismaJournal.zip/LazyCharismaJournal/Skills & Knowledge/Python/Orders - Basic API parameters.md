
- like much like we know already, we will use a params and header to put into the Request for eBay data. 

```
# =========================

# EBAY API REQUEST

import requests

# =========================

url = (

    "https://api.ebay.com/sell/fulfillment/v1/order?"

    f"filter=creationdate:[{str_start_date}..{str_end_date}]"

)

  

headers = {

    "Authorization": f"Bearer {access_token}",

    "Content-Type": "application/json",

}

  

params = {"limit": 200}

  

response = requests.get(url, headers=headers, params=params)

response.raise_for_status()

data = response.json()

```

Here is a table for quick reference of what is happening in this starting code

| Question                       | Example in Your Code         |
| ------------------------------ | ---------------------------- |
| What is the base URL?          | `https://api.ebay.com`       |
| What endpoint are we hitting?  | `/sell/fulfillment/v1/order` |
| What HTTP method?              | `GET`                        |
| Does it need authentication?   | Yes → Bearer Token           |
| What parameters can be passed? | `filter`, `limit`            |
| What format comes back?        | JSON                         |
|                                |                              |

'?' within the URL represents a query, which we pass parameters to like so 
```
https://example.com/users?limit=10
```

for authorization, most documents have this written 

```
headers = {
    "Authorization": f"Bearer {token}"
}
```

- the requests library helps you build query's using variables, so that 
```
params = {"limit": 200}
```

does not need to be manually written everytime you want to make changes 

```
?limit=200
```

of course, we are requesting to get data

```
response = requests.get(url, headers=headers, params=params)
```

- but we can either POST, UPDATE, or DELETE data if we wanted (but for this project)
- this code says "let me request data from this url, let me enter my credentials/token using headers, and this is what I want specifically using params"

We also have error handling as well
```
response.raise_for_status()
```

Which returns one of the following 

| Status Code | Meaning      |
| ----------- | ------------ |
| 200         | Success      |
| 401         | Unauthorized |
| 404         | Not found    |
| 500         | Server error |

we then finally convert the response to json format, which will turn the data in Python Dict/List

```
data = response.json()
```

For parameters we use dates to retrieve data from specific time range, we import

```
from datetime import datetime, timedelta, timezone
```


```
end_date = datetime.now(timezone.utc)

start_date = end_date - timedelta(days=30)

DATE_FORMAT = "%Y-%m-%dT%H:%M:%S.000Z"

str_start_date = start_date.strftime(DATE_FORMAT)

str_end_date = end_date.strftime(DATE_FORMAT)
```

end_date = time of today
start_date = end_date - X days back (timedelta represents a time difference)
Date_format = UTF-8 data encoded to represent a date, in this case, both end_date and start_date
str_start_date/str_end_date = using strftime(DATE_FORMAT), we are encoding the dates into UTF-8, for readability

of course, if we wanted to find a specific date that does not use Today's Date

```
end_date = datetime(YY,MM,DD,HH,MM,SS, tzinfo=timezone.utc)
```

tzinfo=timezone.utc simply represents the time related to the timezone



### How to Read API Documentation 

- won't go to much in-depth, but for practice, 

use the web and find
- find an endpoint you want
- find the headers and params 
- if applicable, find the response body, and also example responses

```
https://developer.ebay.com/api-docs/sell/fulfillment/resources/order/methods/getOrders
```

- here is the API documentation for orders
- With requests and most API's in general (according to Chatgpt), will use similar starting code like headers, params, response, and more. 


So now we can build the starting code from the ground up

```
import requests
from datetime import datetime, timedelta, timezone
from config import access_token




headers = (
"Authorization": f"Bearer {access_token}",
"Content-Type": "application/json"
)

params = {"limit": 200}

end_date = datetime.now(timezone.utc)

start_date = end_date - timedelta(days=30)

DATE_FORMAT = "%Y-%m-%dT%H:%M:%S.000Z"

str_start_date = start_date.strftime(DATE_FORMAT)

str_end_date = end_date.strftime(DATE_FORMAT)


url = (

    "https://api.ebay.com/sell/fulfillment/v1/order?"

    f"filter=creationdate:[{str_start_date}..{str_end_date}]"

)


response = requests.get(url, headers=headers, params=params)
response.raise_for_status()
data = response.json()


```

