
We will have the following parameters when it comes to the exporting to csv function

```
def export_orders_to_csv(data, order_columns, item_columns, filename="orders_testing.csv"):

# data = API call
# orders_columns = Orders Schema
# Item_columns = Items Schema
filename = the CSV file to be produced
```
```

orders = data.get("orders", [])
if not orders:
	print("Orders Not Found")
	return None
```

- Of course, we also add a basic validation to ensure we found orders.

We will also set our keys and rows

```
    rows = []

    existing_keys = set()

    buyer_windows_written = set()
```

- Rows is the List that we will add all of our entries from the specific time date
- Existing_keys is the KEY for each entry. We will use ORDER ID and LINE ITEM ID to identify
- the order ID
- the line ID that falls under the ORDER ID
- Buyer_windows_written is the KEY to identify our method of finding a period of time to appropriately combined shipping, therefore avoiding any error with the shipping cost and maintaining a consistent shipping practice
- We will use The Buyer Username and 24 Hour Card Count Anchor, which represents the ORDER ID for each Line Item ID. This is our way of determining what ORDER IDs are there, and what Line Item IDs fall under it to keep our shipping consistent. 

- IF we already have a existing csv file on run, we simply use a read_csv

```
    if os.path.exists(filename):

        existing_df = pd.read_csv(

            filename,

            usecols=[

                "Order ID",

                "Line Item ID",

                "Buyer Username",

                "Buyer 24h Card Count Anchor"

            ]

        )

  

        existing_keys = set(

            zip(

                existing_df["Order ID"].astype(str),

                existing_df["Line Item ID"].astype(str)

            )

        )

  

        buyer_windows_written = set(

            zip(

                existing_df["Buyer Username"].astype(str),

                existing_df["Buyer 24h Card Count Anchor"].astype(str)

            )

        )
```


We will also create a empty dict to use for Buyers
```
# =========================

    # GROUP ORDERS BY BUYER

    # =========================

    buyer_orders = defaultdict(list)
```

We will now iterated through the orders and find the columns/values that we want.

```
  for order in orders:

        buyer = get_eBayOrders(order, "buyer.username")

        creation_date = get_eBayOrders(order, "creationDate")

        order_time = parse_ebay_datetime(creation_date)

        buyer_orders[buyer].append((order_time, order))


```

- As you see we use a FOR loop to iterate through
- we will use get_eBayOrders, which is simply a function that we take in the API data and the specific path and retrieve the value, specific to the current iterator (or single order)
- Recall: this function uniquely access one of either a dict, or a list (in most of these cases, until we get to the lineItem, it is going to be dict)
- with how it's written (the path)
```
"buyer.username"
```
- we access two paths. One where we access buyer (either a dict with dict inside, or a list, with either more list or dict within). And then username is the key:value we are interested in looking for
- Any inner loop needed to be access simply calls a recursion until we get to the final path and therefore final key

```
import pandas as pd

  

def get_eBayOrders(data, path):

    keys = path.split(".")

  

    current = [data]

  

    for key in keys:

        # print(f"current Key: {key}")

        next_level = []

        for item in current:

            # print(f" Current Length: {len(current)}")

            if isinstance(item, dict):

                val = item.get(key)

                if val is not None:

                    next_level.append(val)

            elif isinstance(item, list):

                    for sub in item:

                        # print(f"Item Length: {len(item)}")

                        if isinstance(sub, dict) and key in sub:

                            # print(sub[key])

                            next_level.append(sub[key])

        # print(f"Next Level: {len(next_level)}")

        current = next_level

  
  

    results = []

    for val in current:

        if isinstance(val, list):

              results.extend(val)

        else:

         results.append(val)

  

    number_values = []

    for n in results:

        try:

            number_values.append(float(n))

        except (TypeError, ValueError):

            pass

  

    if number_values and len(number_values) == len(results):

        return sum(number_values)

    if len(results) == 1:

        return results[0]

    return results
```

- We also need to ensure any values of a LIST are extended to avoid having a entry as type LIST
- we also convert any value to float of numeric, and simply pass if we don't have a numeric value
- in the last few block of code, this validates whether or number_values after conversion matches the length of the results, if so, we simply return the sum of the float (and therefore out results)
- We also want to ensure we return the entry of the list and not the list itself.

- We then get two data from buyer username, and creation date, which we then parse the creation date to type Date. We then append it to the dict buyer_orders.

```
    for buyer in buyer_orders:

        buyer_orders[buyer].sort(key=lambda x: x[0])
```

- we now iterate through the dict of buyers, and iterate through each buyer
- using key=lambda x:x [0], we are wanting to sort through the first column within X range, the first column being Creation Date, and we are also sorting in oldest to newest (ascending)
- key=lambda is important for sorting, and is the equivalent of TABLE sorting in Excel.
- Without it, we would be sorting through more then one column, and more then one TYPE of data, which can result in TypeErrors on runtime.

