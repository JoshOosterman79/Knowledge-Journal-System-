
- Since we use a Time Type to gather data based on a 24-hour window (to see if a Buyer qualified for combined shipping). We use time calculations, and therefore data type TIME (simplified, we use datetime as a type). Therefore, we need to ensure, when retrieving any TIME data from the API that is originally data type STR, to be converted to TIME type for conversion

```
def parse_ebay_datetime(value):

    try:

        return datetime.strptime(value, "%Y-%m-%dT%H:%M:%S.%fZ")

    except ValueError:

        return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
```

- here we take parameter, and convert it to the appropriate time format (I believe this is UTF-8)
- between the two returns you may notice a difference, one taking in milliseconds and the other just seconds. According to ChatGPT, API's can be inconsistent with the formatting of time which is in a String type. Therefore, we want to first try to return the more precise (in miliseconds), if failed, we can fall back to just seconds.