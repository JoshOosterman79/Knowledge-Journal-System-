```
  # =========================
    # BUILD 24H WINDOWS
    # =========================
    buyer_windows = []

    for buyer, entries in buyer_orders.items():
        window = []
        window_start = None

        for order_time, order in entries:
            if not window:
                window = [(order_time, order)]
                window_start = order_time
                continue

            if order_time - window_start <= timedelta(hours=24):
                window.append((order_time, order))
            else:
                buyer_windows.append((buyer, window))
                window = [(order_time, order)]
                window_start = order_time

        if window:
            buyer_windows.append((buyer, window))
```

- In our program, we want to measure how we can properly measure what type of shipping expenses/supplies we are using, the main way is to determine how many cards were shipped, but also if the order qualifies for combined shipment, and therefore more dynamic supplies expense.
- We use this method (24 hour method) to properly measure the count of cards purchased by a buyer, but also to not miscalculate orders if a buyer decides to purchase more cards after a 24 hour window.
- First we created an empty list first (buyer_windows)
- we will then go through buyer_orders list, which we create at the end of Exporting to CSV
- this list contains the buyer (username), and the order_dates and order information. We then assign for an empty variable in Window and set Window_start to None
- we then iterate through each order_time / order (or in general, the item)
- If window is empty (this assumes this is the first entry), we assign order_time and order to the current window, and set the window_start to the order_time, this allows us to iterate through the next order_time.
- If this order_time is under 24 hours, we simply add it to the window list
- If this order_time is over 24 hours, this is a new window, we first add the old buyer/window to the buyer_windows list, followed by window being assign to the newest order, and setting the window_start to the order_time, allowing for a new set of orders to be compared whether or not they are 24 hours less/more 
- In case of any entry that was not added to buyer_window, we simply append IF window contains an entry

Summary:
window -> order_time, order
buyer_windows -> the final list of buyer, and window
window_start -> time of first order, or time of order over 24 hours
