Resources: [Pandas documentation](https://pandas.pydata.org/docs/reference/api/pandas.merge.html)
Project: Consignment/Inventory Builder
Project Description: As we now have two databases, one from building an inventory entry, and then listing that inventory on eBay we now have two databases. One from the source of purchasing, and another one being actively listed on eBay. The goal is to now merge these two tables so that you are able to see the 1) the current price and listing status, and 2) the sourcing data

Recall: When we created our 2 databases in SQLite3, we return a DataFrame just to be able to read it and export to csv/xlsx for example. Here we can use a read database function, to return 2 dataframes, the sourcing and active listings tables.

```
#both a read_db() function that returns df
df_read = read_db()
df_sourcing = addEntriesSourcingPurchases()

result = pd.merge(
    left=df_sourcing,
    right=df_read,
    left_on="skuLabel",
    right_on="sku"
)

result.to_csv("results.csv", index=False)
```

left= - the left side of the table (the first object to be merged)
right = - the right side of the table (the second object to be merged)
left_on = - the left specific column for the table to join
right_on = - the right specific column for the table to join


In this case, SKU label is our key to merge these two tables. This is because
- the SKU label is generated in the sourcing database, and is a combination strings of the entryId, and type of ID.
- the SKU label also determines the specific listing information.

