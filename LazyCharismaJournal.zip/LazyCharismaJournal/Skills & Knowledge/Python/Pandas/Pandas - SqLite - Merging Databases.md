
Resources:
Project:  Consignment - Sourcing Purchases
Project Description: This is a lesson after creating a sourcing purchases database with a SKU label ready to be used to be the key to connect with the SKU's


Once you have an Active Listings Database and Sourcing Purchases Database. We are ready to merge from the Source to the current listings. But many questions arise other then the program?

- How do we list multiple cards from one single SKU? 
- How do we handle quantities, restocks
- How do we handle consignments?


