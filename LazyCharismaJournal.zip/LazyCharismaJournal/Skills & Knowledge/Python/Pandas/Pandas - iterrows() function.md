
Resource: ChatGPT
Project: 
Project Details: We want to add a unique value to each row from a DataFrame using a For Loop and iterrows()

In this case we have a unique Id for each entry, and want to add that after creating a database and calling from Pandas/Excel. When we use Iterrows(). We use index (to determine the position of the row) and row (to access the column and field values for it)

```
for index, row in sourcingPurchases.iterrows():

    entryId = row["entryId"]

    typeInvestment = row["investmentType"][:3]

    sku_label = sku_label_year + "-" + typeInvestment + "-" + entryId

    sourcingPurchases.loc[index, "skuLabel"] = sku_label
  

sourcingPurchases.to_csv("inventory.csv", index=None)
```

