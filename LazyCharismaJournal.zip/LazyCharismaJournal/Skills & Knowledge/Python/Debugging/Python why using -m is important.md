
- In this one, I had issues installing the requests library, I tried the follow

```
pip install requests
py install requests

```
but we use the following 

```
py -m pip install requests
```

- Why like this?

- Well -m essentially **stands for use this module to run the X**. As you may know, we use different Python versions, like 3.11, 3.12, and so on.
- We use the exact version of Python by using -m.

I also seem to forgot how to json dump to a file

with open(".json # file you want to dump to", "w") as f:
	json.dump(data, f, indent=INTEGER)
