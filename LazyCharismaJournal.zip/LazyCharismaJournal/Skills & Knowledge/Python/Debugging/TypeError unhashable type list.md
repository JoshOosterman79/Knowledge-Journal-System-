```
buyer_orders[buyer].append((order_time, order))
    ~~~~~~~~~~~~^^^^^^^
TypeError: unhashable type: 'list'
```

- We will go through the code to find the problem with the code

What we know
- List cannot be hashed, if we have a list like so

```
a_list = [1,2,3,4,5,[6,7,8]]

set(a_list)
```

we draw that exact error above

Solution:
- **Convert list into a tuple**

