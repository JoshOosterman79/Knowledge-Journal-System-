

```
    # =========================

    # EXPLODE WINDOWS

    # =========================

    for buyer, window in buyer_windows:

        total_cards = sum(len(order.get("lineItems", [])) for _, order in window)

        anchor_order_id = str(get_eBayOrders(window[0][1], "orderId"))

        window_key = (buyer, anchor_order_id)

        helper_written = window_key in buyer_windows_written

  

        window_order_total = 0.0

        window_fee_total = 0.0

        max_price = 0.0

        shipping_total = 0.0
```

- if we got each buyer and each order creation date and order information, we now want to access the orders API to get specific data.
- we iterate through buyer and order (order creation date and order data), and get the total length of item(s) within an order.
- noticed we used for , the _ is considered a "throwaway" variable. Since we iterate through window, and therefore order date AND order, we need to consider looping through two variables
- since we only care about order, we use _ to ignore order date, and access lineItems from the order API.
- we could still use order_date in replacement for the _ , but from a reading viewpoint, this is much cleaner.
- we then take the first Order ID from the list, and access the Order to get the OrderID. this can represent the item itself, but also multiple cards as the anchor
- then we create a tuple
- Then we created a boolean variable that checks if that window_key (of buyer username and anchor_id. Anchor_id is of course the first card within a 24 hour order and using that id to represent all cards purchased). This is the way to avoid duplications, it will return False if the CSV file does not contain this entry

After getting the total number of cards, and also creating the anchor_id along with the buyer, we now gather the data representing the shipping cost, fees, and item cost. This is occuring within still the buyer_window list. 


```
        window_order_total = 0.0

        window_fee_total = 0.0

        max_price = 0.0

        shipping_total = 0.0

  

        for _, order in window:

            shipping = get_eBayOrders(order, "lineItems.deliveryCost.shippingCost.value")

            try:

                shipping_total += float(shipping)

            except (TypeError, ValueError):

                pass

            fee = get_eBayOrders(order, "totalMarketplaceFee.value")

            try:

                window_fee_total += float(fee)

            except (TypeError, ValueError):

                pass

            for li in order.get("lineItems", []):

                price = get_eBayOrders(li, "lineItemCost.value")

                try:

                    price = float(price)

                    window_order_total += price

                    max_price = max(max_price, price)

                except (TypeError, ValueError):

                    pass

  

        expense_flag = determine_expense_flag(total_cards, max_price)
```

- We have default values for shipping, fee, item_price, and max_price
- we iterate through window, which is of course, order_date and the order itself (We ignore order_Date)
- we calculate the shipping variable by retrieving from the function that retrieves the value of the path we specificed, in this case shipping
- along with the others, we pass on any TypeErrors 
- we do the same for fee, and price, however we access lineItems in another FOR Loop, as this will be the list that determines how many cards are within the order. We get the sum of all prices of all cards
- Now that we have the total number of cards, and the and the price, we now can call on the expense flag function to see what type of expense we will use !
- Also, note the logic of max price, the program is only interested in the max price of one card, however we would like to change that and make it in general, the order total

```
        expense_flag = determine_expense_flag(total_cards, window_order_total)
```

Now we have order total, fees and shipping expense, we can now create a variable that gets you the Net Revenue

```
  

        net_24h = None

        if total_cards >= 1:

            net_24h = round(

                window_order_total

                + shipping_total

                - window_fee_total

                - (expense_flag or 0),

                2

            )
```

Recall when we created columns (Schemas) for orders and items

```
order_columns = {

    "Buyer Username": "buyer.username",

    "Order ID": "orderId",

    "Creation Date": "creationDate",

    "Order Total": "totalFeeBasisAmount.value",

    "Shipping Charged": "lineItems.deliveryCost.shippingCost.value",

    "Marketplace Fee": "totalMarketplaceFee.value"

}

  

item_columns = {

    "Line Item ID": "lineItemId",

    "SKU": "sku",

    "Title": "title",

    "Quantity": "quantity",

    "Item Price": "lineItemCost.value"

}
```


With both the Order and Item and it's path, we will now access them, and retrieve them

```
    for _, order in window:

            order_base = {}

  

            for col, path in order_columns.items():

                value = get_eBayOrders(order, path)

  

                if path == "creationDate" and isinstance(value, str):

                    dt = parse_ebay_datetime(value)

                    value = dt.strftime("%Y-%m-%d %H:%M:%S")

  

                order_base[col] = value

  

            for item in order.get("lineItems", []):

                row = order_base.copy()

  

                for col, path in item_columns.items():

                    value = get_eBayOrders(item, path)

                    if isinstance(value, list):

                        value = value[0] if value else None

                    row[col] = value
```

- We first look through the paths of the Orders columns, and assign the column to the value that we retrieved
- Of course, with the DATE value that would return as type STRING, we convert to DATE and format it
- we then iterate through the lineitems for each item. We first SAVE the order information as this will tie into each card item. This is more present when there is more then one item
- We then, like Orders, retrieve values from the Item Schema, and properly pass on values if they are type LIST.
- we then assign the columns to values of Items. 

We now want to set-up the rows that calculates the 24-Hour window, the expenses, and net revenue

```
try:

                    price = float(row["Item Price"])

                    row["Sales Tax Allocated"] = round(price * 0.12, 2)

                    row["Promo Fee"] = promo_fee  # ✅ NEW

                except (TypeError, ValueError):

                    row["Sales Tax Allocated"] = None

                    row["Promo Fee"] = None

  

                if not helper_written:

                    row["Buyer 24h Card Count"] = total_cards

                    row["Buyer 24h Card Count Anchor"] = anchor_order_id

                    row["Buyer 24h Order Total"] = round(window_order_total, 2)

                    row["Buyer 24h Marketplace Fee Total"] = round(window_fee_total, 2)

                    row["Expense Flag"] = expense_flag

                    row["Buyer 24h Net Revenue"] = net_24h

  

                    helper_written = True

                    buyer_windows_written.add(window_key)

                else:

                    row["Buyer 24h Card Count"] = None

                    row["Buyer 24h Card Count Anchor"] = None

                    row["Buyer 24h Order Total"] = None

                    row["Buyer 24h Marketplace Fee Total"] = None

                    row["Expense Flag"] = None

                    row["Buyer 24h Net Revenue"] = None

  

                window_rows.append(row)
```

We can first get the Item Price of the Item, followed by calculations to get the sales tax and a promo_fee variable we written in the top of the code

```
promo_fee = round(0.021, 2)
```

-we pass value None if a type/Value Error occurs

- if helper_written is FALSE (therefore, there is not existing buyer, anchor id in the set), we first get the values needed from all the variables we did above
```
                if not helper_written:

                    row["Buyer 24h Card Count"] = total_cards

                    row["Buyer 24h Card Count Anchor"] = anchor_order_id

                    row["Buyer 24h Order Total"] = round(window_order_total, 2)

                    row["Buyer 24h Marketplace Fee Total"] = round(window_fee_total, 2)

                    row["Expense Flag"] = expense_flag

                    row["Buyer 24h Net Revenue"] = net_24h

  

                    helper_written = True

                    buyer_windows_written.add(window_key)
```

- We then set helper_written to TRUE as we now have a record of this particular buyer and their order.
- Now that we do, we add that buyer/order_id to the set of buyers_windows_written
- If helper_written is TRUE (therefore the buyer key is within the list already), and therefore signaling that these columns do not to have data, we simply return None data.
- We then add the row to the window_row

```
        distributed_supplies = split_amount_evenly(expense_flag, len(window_rows))
```


- We now use the Distributed of Price equally function

Practice: can you explain the steps to splitting the prices evenly?


```
        for idx, row in enumerate(window_rows):

            row["Supplies Flag Allocated"] = distributed_supplies[idx]
```

- We use enumeration to track the index/value for each entry of the window_rows
- for row for supplies flag allocation, we assign the return value from the distributed_supplies. 
- Remember: we are returning a list. the Loop here would be the length of the order (or the number of cards within the order)
- therefore, the len of window_rows is the len of the LIST that was returned. 
- And so, we loop through each element and assign it for each entry in the window_rows, until we iterate through all the elements from the list. 

```
  
        for row in window_rows:

            key = (str(row["Order ID"]), str(row["Line Item ID"]))

            if key in existing_keys:

                continue

  

            existing_keys.add(key)

            rows.append(row)
```

- we check every row within window_rows, if we have record of the set of existing_keys, we continue outside the loop, if we don't, we add the key to the set of existing keys
- Finally, our row list that we created in the beginning of the export csv function, is now having entries added!

```
 final_columns = (

        list(order_columns.keys())

        + list(item_columns.keys())

        + [

            "Buyer 24h Card Count",

            "Sales Tax Allocated",

            "Buyer 24h Card Count Anchor",

            "Buyer 24h Order Total",

            "Buyer 24h Marketplace Fee Total",

            "Promo Fee",  # ← right after marketplace context

            "Expense Flag",

            "Supplies Flag Allocated",

            "Buyer 24h Net Revenue",

        ]

    )

  

    df = pd.DataFrame(rows, columns=final_columns)

  

    if os.path.exists(filename):

        df.to_csv(filename, mode="a", header=False, index=False)

    else:

        df.to_csv(filename, index=False)

  

    print(f"✅ Exported {len(df)} rows to {filename}")
```

- We then combine the order_column, item_column, and the calculations columns to one tuple, this will be the column names
- We DataFrame the rows entries, and the column names
- we then check if a csv file exist, if not, we create new one
- we use mode a (append), header is false as we already created some column names, and we don't need index numbers
- We then export to csv, and then your done !

```
export_orders_to_csv(data, order_columns, item_columns, "orders.csv")
```

