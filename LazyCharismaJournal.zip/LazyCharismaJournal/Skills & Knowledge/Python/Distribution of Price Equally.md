- When it comes to the program, we want to use distribution of prices equally among multiple items within an order as this will give us the distribution amount for each item (therefore each SKU, which is what we are looking for more specifically), of supplies expense. 

```
  

def split_amount_evenly(total_amount, n):

    if total_amount is None or n <= 0:

        return [None] * n

  

    total_amount = round(float(total_amount), 2)

    base = round(total_amount / n, 2)

    amounts = [base] * n

  

    current_sum = round(sum(amounts), 2)

    diff = round(total_amount - current_sum, 2)

    amounts[-1] = round(amounts[-1] + diff, 2)

  

    return amounts
```

- Firstly, we assure that we don't have entries <=0, and return an empty list of None.
```
-     total_amount = round(float(total_amount), 2)
```

We first convert out total_amount (could be supplies_expense, shipping_label) to a float and rounded

```
    base = round(total_amount / n, 2)
```

We then get the amount per quantity


```
    amounts = [base] * n
```

we then gather the amount per quantity into a list, and multiple by quantity to get a list of the per quantity of N length

```
    current_sum = round(sum(amounts), 2)
```

- We then round and sum the amount within the list

```
    diff = round(total_amount - current_sum, 2)
```

And subtract to the original (total_amount), this is important as this prevents any miscalculations and missing money from rounding up or down, this is the amount the counts the exact pennies 


```
    amounts[-1] = round(amounts[-1] + diff, 2)
```

We then add this difference to the last entry of the list to ensure the numbers and rounding all line up. Again, we do this as we continue to round, we may lose cents, and multiple entries it can come up to dollars.

QUESTION: Why do we add the difference to the last amount?

```
“We add the difference to one item so the total remains exact while keeping all values at 2 decimal places.”
```

- If we distribute a penny equally to all values in the list, we may experience further rounding issues and is not accurate
