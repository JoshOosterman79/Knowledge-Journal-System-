
- Firstly we need psuedo code / labels to represent what type of expenses for supplies I use to ship orders based on quantity and price

```
def determine_expense_flag(card_count, max_item_price):

    if card_count == 1:

        if max_item_price < 20:

            return 1.18

        elif max_item_price < 30:

            return 1.30

        else:

            return 3.11

  

    elif card_count == 2:

        if max_item_price < 20:

            return 1.18

        elif max_item_price < 30:

            return 1.30

        else:

            return 3.00

  

    elif card_count > 2:

        if max_item_price < 20:

            return 1.13 + ((card_count - 1) * 0.02)

        elif max_item_price < 30:

            return 1.52 + ((card_count - 1) * 0.02)

        else:

            return 2.11 + ((card_count - 1) * 0.02)

  

    return None
```

We will need to consider
- Postage Stamps
- Penny Sleeves
- Toploaders
- Sticky Tabs
- PWE
- BM
- Label
- Cardboard Sleeves

- We can use the following to dynamically get the rate for each supply
- if we record each supply by purchase price, quantity, and then price x quantity, we can use MAX date in excel to get the latest rate
- Firstly, we need to represent all supplies by there name, which means breaking up the order total of supplies (if we assume we purchase more then one supply type) and also distribute the sales tax equally

After gathering all the supplies, there DOP, price, quantity, and cost per unit, we now have a table of values and type of shipment expense
 
|Expense Name|Cost|
|1<20|$                           1.07|
|1<30|$                           1.19|
|1>30|$                           2.03|
|2<20|$                           1.08|
|2<30|$                           1.20|
|2>30|$                           2.04|
|2-5<20|$                           1.14|
|2-5>30|$                           1.50|
|5-X<20|$                           1.58|
|5-X>30|$                           1.58|

so we need to create a source with this data that is dependent on the supplies table, so that it updates the rates automatically

- so what we need to do is 
- in db_2026, create a supplies table that gets all the entries from the supplies book, and use calculations to get the current 'rate' per unit
- Create your shipping rules, and then use those rates to provide calculations, afterwards save the table
- We then create a csv file, that IMPORTS the rates table, now you have a column with the shipping names, and the price
- We then access the csv file via pandas, then have the columns zipped 

```
supplies_expense = dict(zip(df["Expense Name"], df["Cost"]))
```

- By using df[], we refer to the column names within the csv file originally
- by using zip, we create tuples, and using DICT, we create KEY-VALUE to refer to easily
```
return round(supplies_expense["1<20"],2)
```

From there, we successfully create a dynamic expense function ! 

```
import pandas as pd

  

path_name = "supplies_expense_rate.csv"

read_csv = pd.read_csv("supplies_expense_rate.csv")

df = pd.DataFrame(read_csv)

  
supplies_expense = dict(zip(df["Expense Name"], df["Cost"]))

  

def determine_expense_flag(card_count, max_item_price):

    # a fixed cost representing extra cards

    penny_sleeves = 0.025

  

    if card_count == 1:

        if max_item_price < 20:

            return round(supplies_expense["1<20"],2)

        elif max_item_price < 30:

            return round(supplies_expense["1<30"],2)

        else:

            return round(supplies_expense["1>30"], 2)

  

    elif card_count == 2:

        if max_item_price < 20:

            return round(supplies_expense["2<20"],2)

        elif max_item_price < 30:

            return round(supplies_expense["2<30"], 2)

        else:

            return round(supplies_expense["2>30"], 2)

  

    elif card_count > 2<5:

        if max_item_price < 20:

            return round(supplies_expense["2-5<20"],2) + card_count*penny_sleeves

        else:

            return round(supplies_expense["2-5>30"],2) + card_count*penny_sleeves

    elif card_count > 5:

        if max_item_price < 20:

            return round(supplies_expense["5-X<20"], 2) + card_count*penny_sleeves

        else:

            return round(supplies_expense["5-X>30"], 2) + card_count*penny_sleeves

    return None
```


