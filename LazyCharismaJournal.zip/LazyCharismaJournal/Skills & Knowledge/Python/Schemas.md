
- recall that you used a function that got you the paths that you wanted
```
  

def printPaths(data, seen=None, path=""):


    if seen is None:

        seen = set()

    if isinstance(data, dict):

        for key, value in data.items():

            full_path = f"{path}.{key}" if path else key

            if full_path not in seen:

                print(full_path)

                seen.add(full_path)

            printPaths(value, seen, full_path)

    elif isinstance(data, list):

        if all(isinstance(item, dict) for item in data):

            full_path = f"{path}[] <-- List"

        if full_path not in seen:

            print(full_path)

            seen.add(full_path)

            if data:

                printPaths(data[0], seen, path)
```

- However, it may be easier to use a Schema, as It does not need to go through a function each time, but rather a list of entries 
- We are only worried about the Schemas that we get directly from GET, later on you will see other columns/data that we can retrieve only after getting the initial data from the GET call

```
order_columns = {

    "Buyer Username": "buyer.username",

    "Order ID": "orderId",

    "Creation Date": "creationDate",

    "Order Total": "totalFeeBasisAmount.value",

    "Shipping Charged": "lineItems.deliveryCost.shippingCost.value",

    "Marketplace Fee": "totalMarketplaceFee.value"

}

  

item_columns = {

    "Line Item ID": "lineItemId",

    "SKU": "sku",

    "Title": "title",

    "Quantity": "quantity",

    "Item Price": "lineItemCost.value"

}
```
