
- Refer to my Chit Chats Program for more detail

In my code I have the following output of Title 

1 Mega Greninja ex SAR 114/083 M4 Ninja Spinner Pokemon Card Japanese PRE-ORDER

- While this code successful produced what I want, by default it produces a 1 in front of the title which we want to ignore/remove if we are playing with Lookups.

From here we use the following

```
title = "1 Mega Greninja ex SAR 114/083 M4 Ninja Spinner Pokemon Card Japanese PRE-ORDER"

title = title.removeprefix("1 ")

print(title)
```

- This would remove the beginning prefix or string ("1 ") within the title. Another way is using 

```
.replace("1 ", "", 1)
```

But this could cause issues if our title has more then one "1", by using removeprefix we only remove the beginning "1 "

