
We have the following sub folder we want to access to retrieve the Excel Sheet

```
Sub folder / data / needed_file.xlsx
Sub folder 2 / calling from here
```

First we import the PathLib library
```
from pathlib import Path
```

What is PathLib?

- A way to manipulate and navigate through files without having to hardcode the string/paths. Here we created objects of these paths and, in our case, direct them to what file we want to retrieve.

In this case, we first get our current working folder

```
current_folder = Path(__file__).parent
print(current_folder)

Prints: #c:\Users\pokem\OneDrive\Desktop\my_project_folder\projects\my_programming_projects\Projects\consignment_project_beta

```
We then need to access Projects mainly
```
  

projects_folder = current_folder.parent

print(projects_folder)

Prints:
c:\Users\pokem\OneDrive\Desktop\my_project_folder\projects\my_programming_projects\Projects
```

Now that we are in the main Parent folder, we can now create a Path by combining strings using the slash '/' 

```
excel_path = projects_folder / "ebay_orders_projects_v1" / "data" / "inventory_book.xlsx"

print(excel_path)

Prints:
c:\Users\pokem\OneDrive\Desktop\my_project_folder\projects\my_programming_projects\Projects\ebay_orders_projects_v1\data\inventory_book.xlsx
```

- Now we can access the Excel sheet that we want using pandas

```
df = pd.read_excel(excel_path)
```


