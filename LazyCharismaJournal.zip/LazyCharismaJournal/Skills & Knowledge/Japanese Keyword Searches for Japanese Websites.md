Now that we have a database based on the sets we downloaded, and translated well for english and maintain the japanese katakana language, we can now use these values to search on websites such as 

Mercari 

and later on in future versions

- JDirect Auctions
- Rakuma
- SNKRDUNK
- and other sources

For simplicity sake, I will just have a table of copy/paste values , as I don't require ALL japanese cards in the set, but rather the expensive ones that are valuable and in-demand more.

We can take a look at some cards from the Abyss Eye set, and find 2-3 in mind

|                                 |
| ------------------------------- |
| Darkrai SAR Abyss Eye 114/81 m5 |

So what are we exactly using to look-up this card?

Well, we have a tool actually for that.

https://github.com/marvinody/mercari/

- this allows me to search for a specific card, and retrieve the data needed. So my goal, to understand the code and can piece together to create my own. I will reverse engineer this program. Break down each component into lessons I might already know and need review, and also learn what I need as well.


