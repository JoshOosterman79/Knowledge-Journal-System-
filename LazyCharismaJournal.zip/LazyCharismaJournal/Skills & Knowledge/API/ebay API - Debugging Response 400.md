
we usually use

```
response.raise_for_status()
```

although we get whether we raise a 400 or sucess (raise 200), we don't know the exact problem if we raise 400. So we can diagnose 400 by doing the following

```
    print(response.status_code)

    print(response.text)

    print(response.url)
```

We get 
- the status_code
- the text/explanation of the error (most important)
- the url of the endpoint we used