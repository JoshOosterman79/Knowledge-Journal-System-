
Before even calling the API for Traffic and Analytics, we must first gather Active Listings and their ID. Recall we used XML as a way to gather the Active Listings, and access each Element to get active listing data. 

```
def get_active_listings():

    headers = {
        "X-EBAY-API-CALL-NAME": "GetMyeBaySelling",
        "X-EBAY-API-SITEID": "2",
        "X-EBAY-API-COMPATIBILITY-LEVEL": "1475",
        "X-EBAY-API-IAF-TOKEN": access_token,
        "Content-Type": "text/xml"
    }

    body = """
    <?xml version="1.0" encoding="utf-8"?>
    <GetMyeBaySellingRequest xmlns="urn:ebay:apis:eBLBaseComponents">

        <ActiveList>
            <Include>true</Include>

            <Pagination>
                <EntriesPerPage>3</EntriesPerPage>
                <PageNumber>1</PageNumber>
            </Pagination>

        </ActiveList>

    </GetMyeBaySellingRequest>
    """

    response = requests.post(
        TRADING_URL,
        headers=headers,
        data=body.strip()
    )

    response.raise_for_status()

    root = ET.fromstring(response.content)

    NS = {
        "e": "urn:ebay:apis:eBLBaseComponents"
    }

    listings = []

    for item in root.findall(".//e:ActiveList/e:ItemArray/e:Item", NS):

        listing = {
            "itemId": item.findtext("e:ItemID", namespaces=NS),
            "title": item.findtext("e:Title", namespaces=NS),
            "sku": item.findtext("e:SKU", namespaces=NS),
        }

        listings.append(listing)

    return listings


# ---------------------------------------------------
# 2. RETURN TRAFFIC DATA FOR THOSE LISTINGS
# ---------------------------------------------------

def get_traffic_data(listings):

    listing_ids = [
        listing["itemId"]
        for listing in listings
    ]

    end_date = date.today() - timedelta(days=1)
    start_date = end_date - timedelta(days=30)

    date_filter = (
        f"{start_date.isoformat()}T00:00:00.000Z"
        f".."
        f"{end_date.isoformat()}T23:59:59.999Z"
    )

    headers = {
    "Authorization": f"Bearer {access_token}",
    "Accept": "application/json",
    "Content-Language": "en-CA",
    }

    metrics = ",".join([
        "TOTAL_IMPRESSION_TOTAL",
        "LISTING_VIEWS_TOTAL",
        "LISTING_VIEWS_SOURCE_OFF_EBAY",
        "CLICK_THROUGH_RATE",
        "TRANSACTION",
        "SALES_CONVERSION_RATE"
    ])

    listing_filter = "|".join(listing_ids)

    params = {
        "dimension": "LISTING",

        "filter": (
            f"listing_ids:{{{listing_filter}}}",
            f"date_range:[{date_filter}]"
        ),

        "metric": metrics
    }

    response = requests.get(
        ANALYTICS_API_ENDPOINT,
        headers=headers,
        params=params,
        timeout=request_timeout
    )

    response.raise_for_status()
    # print(response.status_code)
    # print(response.text)
    # print(response.url)

    return response.json()
```

We notice that our response return looks like this 

```
{
   "header": {
      "dimensionKeys": [
         {
            "localizedName": "Listing id",
            "key": "LISTING_ID",
            "dataType": "STRING"
         }
      ],
      "metrics": [
         {
            "localizedName": "Total impressions",
            "key": "TOTAL_IMPRESSION_TOTAL",
            "dataType": "NUMBER"
         },
         {
            "localizedName": "Off eBay views",
            "key": "LISTING_VIEWS_SOURCE_OFF_EBAY",
            "dataType": "NUMBER"
         },
         {
            "localizedName": "Total views",
            "key": "LISTING_VIEWS_TOTAL",
            "dataType": "NUMBER"
         },
         {
            "localizedName": "Transaction count",
            "key": "TRANSACTION",
            "dataType": "NUMBER"
         },
         {
            "localizedName": "Click through rate",
            "key": "CLICK_THROUGH_RATE",
            "dataType": "NUMBER"
         },
         {
            "localizedName": "Sales conversion rate",
            "key": "SALES_CONVERSION_RATE",
            "dataType": "NUMBER"
         }
      ]
   },
   "records": [
      {
         "dimensionValues": [
            {
               "value": "318616944443",
               "applicable": true
            }
         ],
         "metricValues": [
            {
               "value": 126116,
               "applicable": true
            },
            {
               "value": 13,
               "applicable": true
            },
            {
               "value": 237,
               "applicable": true
            },
            {
               "value": 0,
               "applicable": true
            },
            {
               "value": 0.02,
               "applicable": true
            },
            {
               "value": 0.0,
               "applicable": true
            }
         ]
      },
      {
         "dimensionValues": [
            {
               "value": "318397817444",
               "applicable": true
            }
         ],
         "metricValues": [
            {
               "value": 1227,
               "applicable": true
            },
            {
               "value": 0,
               "applicable": true
            },
            {
               "value": 3,
               "applicable": true
            },
            {
               "value": 0,
               "applicable": true
            },
            {
               "value": 0.0,
               "applicable": true
            },
            {
               "value": 0.0,
               "applicable": true
            }
         ]
      },
      {
         "dimensionValues": [
            {
               "value": "318397817432",
               "applicable": true
            }
         ],
         "metricValues": [
            {
               "value": 454,
               "applicable": true
            },
            {
               "value": 0,
               "applicable": true
            },
            {
               "value": 2,
               "applicable": true
            },
            {
               "value": 0,
               "applicable": true
            },
            {
               "value": 0.0,
               "applicable": true
            },
            {
               "value": 0.0,
               "applicable": true
            }
         ]
      }
   ],
   "warnings": [],
   "startDate": "2026-07-21T00:00:00.000Z",
   "endDate": "2026-08-20T23:59:59.000Z",
   "lastUpdatedDate": "2026-08-21T22:49:00.415Z"
}
```

A weird response then usual and it's not exact like a key:value and we retrieve the key. What is going on is this.

```
      "metrics": [
         {
            "localizedName": "Total impressions",
            "key": "TOTAL_IMPRESSION_TOTAL",
            "dataType": "NUMBER"
         },
         {
            "localizedName": "Off eBay views",
            "key": "LISTING_VIEWS_SOURCE_OFF_EBAY",
            "dataType": "NUMBER"
         },
         {
            "localizedName": "Total views",
            "key": "LISTING_VIEWS_TOTAL",
            "dataType": "NUMBER"
         },
         {
            "localizedName": "Transaction count",
            "key": "TRANSACTION",
            "dataType": "NUMBER"
         },
         {
            "localizedName": "Click through rate",
            "key": "CLICK_THROUGH_RATE",
            "dataType": "NUMBER"
         },
         {
            "localizedName": "Sales conversion rate",
            "key": "SALES_CONVERSION_RATE",
            "dataType": "NUMBER"
         }
```

These are your columns, and are actually indexed. 
```
"records": [
      {
         "dimensionValues": [
            {
               "value": "318616944443",
               "applicable": true
            }
         ],
         "metricValues": [
            {
               "value": 126116,
               "applicable": true
            },
            {
               "value": 13,
               "applicable": true
            },
            {
               "value": 237,
               "applicable": true
            },
            {
               "value": 0,
               "applicable": true
            },
            {
               "value": 0.02,
               "applicable": true
            },
            {
               "value": 0.0,
               "applicable": true
            }
         ]
      },
      { ...
```

This is the records and have X amount of the active_listings that you inputted into the parameter. In our small code we had 3, and therefore we have a len of 3 records. What we want is the following

- Retrieve the records and print each of them (should be 3 in this case)
- Retrieve the values that would represent the data fields of those columns or metrics we are looking for
- create a table for the 3 entries

