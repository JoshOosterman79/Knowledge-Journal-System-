
In around 45 minutes, I manage to list on eBay 112 bulk cards


