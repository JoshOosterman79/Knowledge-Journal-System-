# SKU / Shipment Analysis

**Date:**  
**SKU / Shipment:**  
**Product / Set:** 
**Category:** 

---

## Summary

**Purchase Date:** 
**Quantity Purchased:** 
**Purchase Cost:** 
**Import / Customs Cost:** 
**Total Landed Cost:** 
**Average Cost Per Unit:**  

**Average Selling Price:** 
**Quantity Sold:** 
**Quantity Remaining:**  
**Current Market Price:** 

**Revenue:** 
Account Receivables: 
**Gross Profit:** $  
Gross Profit %: 



eBay Variable Fees: 
eBay Fixed Fees: 
eBay Promo Fees: 

Total: 86.57 


**Net Profit:** $  
**Net Margin:** %

**Average Days to Sell:**  
**Sell-Through Rate:** %

**Impressions:**  
**Views:**  
**CTR:** %  
**Conversion Rate:** %  
**Watchers / Offers:**

**Current Status:** Active / Sold Out / Holding / Discounting / Liquidating

**Current Decision:** Buy More / Hold / Maintain / Reduce / Stop Buying / Monitor

---

## Analysis Journal

**What stands out to me?**

---

**What do I think happened, and why?**

---

**What did I expect compared with what actually happened?**

---

**What did I do well?**

---

**What would I do differently?**

---

**What does this teach me about this SKU, shipment, or market?**

---

**What should I do next?**

---

**Notes / Thoughts:**