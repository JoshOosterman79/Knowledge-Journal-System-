
2026-08-07

- In this entry, we are looking at 3 SKU that heavily relied on consignment orders to see if the new main business model (that is having a purchase from a buyer first then sourcing inventory).

The following SKU's we are taking a look at

2026-SH1-JPJULY*
2026-SH2-JPJULY*
2026-SH3-JPJULY*

With Items/Cards as 

Mega Darkrai ex 
B&W Vintage Holos
Mega Zeraora ex
Mega Gengar ex 
Magikarp AR 080/073 ,  Reshiram EX 168/086 , Iron Leaves ex 093/071
Iron Leaves ex 093/071
Mega Darkrai ex 114/081
Mega Pikachu ex 234/193
Mega Greninja ex 114/083
Mega Greninja ex 114/083
Pokemon Center Fukuoka Box


The following Item's have been exempt as these will be sold on Facebook or on store
Mega Darkrai ex 
B&W Vintage Holos
1x Mega Greninja ex 114/083


the Following Prices are

| SKU              | Inventory Cost                                     |
| ---------------- | -------------------------------------------------- |
| 2026-SH1-JPJULY* | $                                           677.05 |
| 2026-SH2-JPJULY* | $                                           651.96 |
| 2026-SH3-JPJULY* | $                                           894.01 |

|                  | Import Costs                                       |
| ---------------- | -------------------------------------------------- |
| 2026-SH1-JPJULY* | $                                           150.65 |
| 2026-SH2-JPJULY* | $                                           141.48 |
| 2026-SH3-JPJULY* | $                                           182.19 |

|                  | Total Cost                                         |
| ---------------- | -------------------------------------------------- |
| 2026-SH1-JPJULY* | $                                           827.70 |
| 2026-SH2-JPJULY* | $                                           793.44 |
| 2026-SH3-JPJULY* | $                                      1,076.20    |


# In total Between July 13 (my first consignment sale), and August 1st we Net 6 sales. With exception of 1 sale which was an item I already had in stock, and another which was cancelled.


| Title                                                                         | Sold Price |
| ----------------------------------------------------------------------------- | ---------- |
| Pokémon Japanese Mega Zeraora ex m5 Abyss Eye 112/081 SAR PRE-ORDER           | 55.28      |
| MEGA Gengar ex SAR 240/193 MEGA Dream ex M2a Pokemon Card 2025 Japanese       | 487.87     |
| Mega Darkrai ex SAR 114/081 M5 Abyss Eye Pokemon Japanese 2026 PRE-ORDER      | 332.88     |
| Pikachu ex SAR 234/193 MEGA Dream ex M2a Pokemon Card Japanese 2025 PRE-ORDER | 279.56     |
| Mega Greninja ex SAR 114/083 M4 Ninja Spinner Pokemon Card Japanese PRE-ORDER | 321.88     |
| 2025 Pokemon SEALED Japanese Pokemon Center Fukuoka Pikachu Box               | 264.99     |
|                                                                               |            |
 
Pikachu ex SAR 234/193 MEGA Dream ex M2a Pokemon Card Japanese 2025 PRE-ORDER	239.09
Mega Greninja ex SAR 114/083 M4 Ninja Spinner Pokemon Card Japanese PRE-ORDER	276.15
2025 Pokemon SEALED Japanese Pokemon Center Fukuoka Pikachu Box	226.62
Mega Darkrai ex SAR 114/081 M5 Abyss Eye Pokemon Japanese 2026 PRE-ORDER	285.6
MEGA Gengar ex SAR 240/193 MEGA Dream ex M2a Pokemon Card 2025 Japanese	424.49
Pokémon Japanese Mega Zeraora ex m5 Abyss Eye 112/081 SAR PRE-ORDER	47.19

| Title                                                                         | Net Amount |
| ----------------------------------------------------------------------------- | ---------- |
| Pikachu ex SAR 234/193 MEGA Dream ex M2a Pokemon Card Japanese 2025 PRE-ORDER | 239.09     |
| Mega Greninja ex SAR 114/083 M4 Ninja Spinner Pokemon Card Japanese PRE-ORDER | 276.15     |
| 2025 Pokemon SEALED Japanese Pokemon Center Fukuoka Pikachu Box               | 226.62     |
| Mega Darkrai ex SAR 114/081 M5 Abyss Eye Pokemon Japanese 2026 PRE-ORDER      | 285.6      |
| MEGA Gengar ex SAR 240/193 MEGA Dream ex M2a Pokemon Card 2025 Japanese       | 424.49     |
| Pokémon Japanese Mega Zeraora ex m5 Abyss Eye 112/081 SAR PRE-ORDER           | 47.19      |

Let's then get the Shipping/Tracking required for these items

| Title                                                                         | Shipping Cost |
| ----------------------------------------------------------------------------- | ------------- |
| Pikachu ex SAR 234/193 MEGA Dream ex M2a Pokemon Card Japanese 2025 PRE-ORDER | 11.65         |
| Mega Greninja ex SAR 114/083 M4 Ninja Spinner Pokemon Card Japanese PRE-ORDER | 11.65         |
| 2025 Pokemon SEALED Japanese Pokemon Center Fukuoka Pikachu Box               | 13.62         |
| Mega Darkrai ex SAR 114/081 M5 Abyss Eye Pokemon Japanese 2026 PRE-ORDER      | 11.65         |
| MEGA Gengar ex SAR 240/193 MEGA Dream ex M2a Pokemon Card 2025 Japanese       | 13.62         |
| Pokémon Japanese Mega Zeraora ex m5 Abyss Eye 112/081 SAR PRE-ORDER           | 8.12          |

In Total We have the following Net Amount. Keep in mind we will use 1$ supplies expense for the net revenue

| Pikachu ex SAR 234/193 MEGA Dream ex M2a Pokemon Card Japanese 2025 PRE-ORDER | 226.44 |
| ----------------------------------------------------------------------------- | ------ |
| Mega Greninja ex SAR 114/083 M4 Ninja Spinner Pokemon Card Japanese PRE-ORDER | 263.5  |
| 2025 Pokemon SEALED Japanese Pokemon Center Fukuoka Pikachu Box               | 212    |
| Mega Darkrai ex SAR 114/081 M5 Abyss Eye Pokemon Japanese 2026 PRE-ORDER      | 272.95 |
| MEGA Gengar ex SAR 240/193 MEGA Dream ex M2a Pokemon Card 2025 Japanese       | 409.87 |
| Pokémon Japanese Mega Zeraora ex m5 Abyss Eye 112/081 SAR PRE-ORDER           | 38.07  |
# Total Net Revenue: $1422.83

Now Lets see the associated SKU from the Total Cost

|                  | Total Cost                                         |
| ---------------- | -------------------------------------------------- |
| 2026-SH1-JPJULY* | $                                           827.70 |
| 2026-SH2-JPJULY* | $                                           793.44 |
| 2026-SH3-JPJULY* | $                                      1,076.20    |


| Title                                                                         | SKU                         | Net Amount |     |
| ----------------------------------------------------------------------------- | --------------------------- | ---------- | --- |
| Mega Greninja ex SAR 114/083 M4 Ninja Spinner Pokemon Card Japanese PRE-ORDER | 2026-SH3-JPJULY-PRI<br>     | 263.5      |     |
| 2025 Pokemon SEALED Japanese Pokemon Center Fukuoka Pikachu Box               | 2026-SH3-JPJULY-PRI<br>     | 212        |     |
| Mega Darkrai ex SAR 114/081 M5 Abyss Eye Pokemon Japanese 2026 PRE-ORDER      | 2026-SH2-JPJULY-PRI<br><br> | 272.95     |     |
| MEGA Gengar ex SAR 240/193 MEGA Dream ex M2a Pokemon Card 2025 Japanese       | 2026-SH1-JPJULY-PRI<br><br> | 409.87     |     |
| Pokémon Japanese Mega Zeraora ex m5 Abyss Eye 112/081 SAR PRE-ORDER           | 2026-SH1-JPJULY-PRI<br><br> | 38.07      |     |
| Pikachu ex SAR 234/193 MEGA Dream ex M2a Pokemon Card Japanese 2025 PRE-ORDER | 2026-SH3-JPJULY-PRI<br>     | 226.44     |     |


# In Net Sales

| 2026-SH1-JPJULY* | 447.94 |
| ---------------- | ------ |
| 2026-SH2-JPJULY* | 272.95 |
| 2026-SH3-JPJULY* | 701.94 |

# From Profits / Loss So Far

| 2026-SH1-JPJULY* | - 379.76 |
| ---------------- | -------- |
| 2026-SH2-JPJULY* | - 520.49 |
| 2026-SH3-JPJULY* | - 374.26 |

Now Lets Consider The rest of my inventory

|                  | Total Cost                                         |
| ---------------- | -------------------------------------------------- |
| 2026-SH1-JPJULY* | $                                           827.70 |
| 2026-SH2-JPJULY* | $                                           793.44 |
| 2026-SH3-JPJULY* | $                                      1,076.20    |
|                  |                                                    |

|                  | Total Cost (adj)                                    |
| ---------------- | --------------------------------------------------- |
| 2026-SH1-JPJULY* | $                                             489.5 |
| 2026-SH2-JPJULY* | $                                           337.36  |
| 2026-SH3-JPJULY* | $                                          804.15   |
|                  |                                                     |
- Here we adjusted for Inventory that we purchased but not sold yet along with customs of 12%, and the plan fee at 4.2$. So now from now a profit/loss of just the consignment items themselves (and extra cost of shipping for simplicity, we have)

# Net Sales Table

| 2026-SH1-JPJULY* | 447.94 |
| ---------------- | ------ |
| 2026-SH2-JPJULY* | 272.95 |
| 2026-SH3-JPJULY* | 701.94 |
# Profit/Lose based on sold consignments

| 2026-SH1-JPJULY* | -41.56  |     |
| ---------------- | ------- | --- |
| 2026-SH2-JPJULY* | -64.41  |     |
| 2026-SH3-JPJULY* | -102.21 |     |
# Net/Loss: - 208.18

- Lets now consider what if we sell at the rest of the inventory at the price we listed

# Remaining Inventory to Sell

| 2026-SH1-JPJULY* | $456 |
| ---------------- | ---- |
| 2026-SH2-JPJULY* | $585 |
| 2026-SH3-JPJULY* | $350 |
Here we now have the remaining NET sales remaining, which we add to the total sales



# Total Net Sales + Remaining Inventory to Sell

| 2026-SH1-JPJULY* | 904     |     |
| ---------------- | ------- | --- |
| 2026-SH2-JPJULY* | 857.95  |     |
| 2026-SH3-JPJULY* | 1051.94 |     |

Now our Net/Loss is 

|                  | Total Cost                                         |
| ---------------- | -------------------------------------------------- |
| 2026-SH1-JPJULY* | $                                           827.70 |
| 2026-SH2-JPJULY* | $                                           793.44 |
| 2026-SH3-JPJULY* | $                                      1,076.20    |
|                  |                                                    |

# Net/Loss Profit Total Net Sales + Remaining Inventory to Sell

| 2026-SH1-JPJULY* | $76.3   |
| ---------------- | ------- |
| 2026-SH2-JPJULY* | $64.51  |
| 2026-SH3-JPJULY* | $-24.26 |
| Total:           | $116.55 |
# Or around 4% Margin


Now Let's Consider the Amount of Discounts I've Given through Store Discount/Sales

| 2026-SH1-JPJULY* |        |        |
| ---------------- | ------ | ------ |
| 2026-SH2-JPJULY* | $28.95 | 8% off |
| 2026-SH3-JPJULY* | $52.3  | 8% off |

And Now Best Offers (rough estimate, and conservative)

| 2026-SH1-JPJULY* |     |
| ---------------- | --- |
| 2026-SH2-JPJULY* | $40 |
| 2026-SH3-JPJULY* | $35 |

So I left out

| 2026-SH1-JPJULY* |        | $35 | $35   |
| ---------------- | ------ | --- | ----- |
| 2026-SH2-JPJULY* | $28.95 | $40 | $69   |
| 2026-SH3-JPJULY* | $52.3  |     | $52.3 |
# Total: $156.3

**Which would of been $255.67 in profits rather then $116.55, increase profit margins from 4% to 9%**


Personal Feedback:
- Watch the profits by ensuring Discounts/Best Offers are calculated decisions
- We can slightly increase prices before sales so that we predict margins a little more if needed
- We can really sure net profits by selling on Facebook, and or charge the selling fee on eBay, which we usually did not do


Personal Notes
- I think the analysis of tracking pre-orders/consignments took to long (around 2 hours)
- Log Runtime of Code so that you do not miss out on missed orders, or atleast have record showing what you need to run
- We Need a better way to track pre-orders/consignment listings using SKU
- I would like a more structured system that allows me to track SKU Profits/Loss
- Properly get a floor margin and never go below that, and then a margin which considers a sale
- I also want to ensure the service in itself doesn't take a dip and can improve. So there should be a line of how much someone is willing to pay and how satisfied they are with this service.
