
- 2026-BulkJuly is cards I essentially got for free and want to monitor the algorithm.

The Contain contains 77 listings of 0.99 cards from the obsidian Flame set. all with free shipping attached, and listed at around 6 per day. 