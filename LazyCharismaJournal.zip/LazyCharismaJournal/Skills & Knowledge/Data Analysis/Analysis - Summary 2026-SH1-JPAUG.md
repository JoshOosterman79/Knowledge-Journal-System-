# SKU / Shipment Analysis

**Date:**  
**SKU / Shipment:**  2026-SH1-JPAUG
**Product / Set:**  Storm Emeralda
**Category:** Consignment / Regular 

---

## Summary


What I did for proper SKU/inventory sold tracking is I took the sales in total of the SKU, and subtract by the purchase(s) that share the same SKU, but await to be in-hand


**Purchase Date:**  2026-08-01 - 2026-08-06
**Quantity Purchased:**  ~95
**Purchase Cost:** $  2,122.59
**Import / Customs Cost:** $ 417.66 
**Total Landed Cost:** $   $2,540.25 
**Average Cost Per Unit:**  ~$27

**Average Selling Price:** $  ~32
**Quantity Sold:**  46-9 = 37 (accounted for cards not in-hand right now, but sold)
**Quantity Remaining:**  56
**Current Market Price:** $ ~220.5 (of the quantity remaining)

**Revenue:** $  1,629.15 - 997.94 = $631.21 (adjusted for Morpeko ex, and the sales made but awaiting to be in-hand)
Discounts: 23.28
Account Receivables: 2,070
Gross Sales: 2701.21

**Gross Profit:** $  160.96
Gross Profit %: 6%

est. based on $631.21 of sales

Total eBay Fees: $95.41

Supplies Expenses: $40
Shipping Expenses: $24.51

With Booster Box: you are probably around 40-50$ at a loss
**Net Profit:** $  1.04
**Net Margin:** % 
Status: Breakeven

**Average Days to Sell:**  
**Sell-Through Rate:** %

**Impressions:**  
**Views:**  
**CTR:** %  
**Conversion Rate:** %  
**Watchers / Offers:**

**Current Status:** Active / Sold Out / Holding / Discounting / Liquidating

**Current Decision:** Buy More / Hold / Maintain / Reduce / Stop Buying / Monitor

---

## Analysis Journal

**What stands out to me?**

---

**What do I think happened, and why?**

---

**What did I expect compared with what actually happened?**

---

**What did I do well?**

---

**What would I do differently?**

---

**What does this teach me about this SKU, shipment, or market?**

---

**What should I do next?**

---

**Notes / Thoughts:**