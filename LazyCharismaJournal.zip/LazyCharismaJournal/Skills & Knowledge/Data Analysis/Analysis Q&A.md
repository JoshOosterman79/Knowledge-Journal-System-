As of 2026-07-02

** 
What is the 20% of SKU producing 80% of the revenue?

```
|2026-S2-JPMAY|696.38|55|11.02%|
|2026-JPJUNE-CONSIGN|590|1|9.34%|
||512.29|4|8.11%|
|2026-JPMARP2|365|2|5.78%|
|2026-S2-JPMAY-PRI|332.76|5|5.27%|
|2026-JPJAN-PA|331.68|41|5.25%|
|2026-*|267.04|79|4.23%|
|2025-COMCOCT-3MA|261.21|33|4.14%|
|2026-S2-JPMAR*|260.29|2|4.12%|
|2025-JPDEC*|260.29|1|4.12%|
|2026-JPMAR-STRD|256.85|25|4.07%|
|2026-JPMARP2*|238.1|30|3.77%|
|2025-JPNOV-QFBPA|222.28|29|3.52%|
|2026-JPFEB-STRD|221.54|15|3.51%|
|2026-JPMAY-STRD|155.17|30|2.46%|
|2026-COMCMAY-STRD|132.84|6|2.10%|
|2026-S3-JPMAR-PRI|123.04|11|1.95%|
```

- This is this years 80% of Revenue.

What we Noticed

- S2-JPMAY/JPMARP2/S2-JPMAY-PRI/JPJAN are all pre-orders. 
- JPMAR was a custom order
- JPJUNE-CONSIGN was a one-time consignment

**Pre-Orders Made of 31% of Revenue (If we want to include consignment, is 40%)

Let's take a closer look at June's Numbers, which was your highest in revenue

```
2026-JPJUNE-CONSIGN	590	1	41.00%
2026-S2-JPMAY-PRI	332.76	5	23.12%
2026-S2-JPMAY	240.01	23	16.68%
2026-COMCMAY-STRD	97.26	4	6.76%
2026-BULKJUNE-STRD	57.42	58	3.99%
2026-JPMAY-STRD	47.96	11	3.33%

```

**As you see, 95% of Revenue came from cards I just added in the store from June.** 
And 80% is revenue comes from Pre-Orders/Consignment

If we Take a Look at March, the second highest in revenue

```
2026-S2-JPMAR*	260.29	2	19.37%
2026-JPMARP2*	226.52	28	16.86%
2026-JPFEB-STRD	168.13	5	12.51%
2026-JPMARP2	165	1	12.28%
2026-*	111.26	16	8.28%
2026-JPMAR-STRD	75.16	5	5.59%
2025-Derrick	42.16	5	3.14%
2026-JPJAN-QFBPA	40.37	1	3.00%

```

50% of the Revenue is Pre-Orders

Questions/Metrics
- How far can we scale up pre-orders?
- What to do in months that don't contain pre-orders?



What is the 20% of SKU producing 80% of the profits?

- We are actually going to take a look at the AR's purchased for pre-order for each SKU, and also compare to COMC


Experiment with 2026-JUNEBULK



