
- We are gathering data that will help us improve our revenue/cash-flow knowing the new release vs non-release months.


|                    |         |                 |
| ------------------ | ------- | --------------- |
| Japanese Inventory |         |                 |
| Month              | New Set | Date of Release |
| JAN                | y       | 01-23-26        |
| FEB                | n       |                 |
| MAR                | y       | 03-23-26        |
| APR                | n       |                 |
| MAY                | y       | 05-22-26        |
| JUN                | n       |                 |
| JUL                | y       |                 |
| AUG                |         |                 |
| SEP                |         |                 |
| OCT                |         |                 |
| NOV                |         |                 |
| DEC                |         |                 |


|   |   |   |   |   |
|---|---|---|---|---|
   
No-Release SKU Summary
Feb Sales Quantity % of Grand SCaalteesgory
2025-COMCOCT-3MA $ 58.34 9 22% Sport Cards
2026-* $ 42.06 12 16% ETC (older Japanese, cheap holos)
2026-JPJAN-PA $ 31.63 6 12% New Release
2025-JPNOV-QFBPA $ 27.26 6 10% ETC (older Japanese, cheap holos)
2025-JPAUG-BPQFA $ 23.67 3 9% ETC (older Japanese, cheap holos)
Total $ 182.96 36 69%
Apr
2026-JPMAR $ 4 65.00 2 56% New Release
2026-S2-JPMAR-PRI $ 85.13 4 10% New Release
2026-JPMAR-STRD $ 75.63 10 9% Standard Inventory
2026-INV $ 53.58 2 6% Investments
2026-* $ 40.43 7 5% ETC (older Japanese, cheap holos)
Total $ 719.77 25 86%
June
2026-JPJUNE-CONSIGN $ 5 90.00 1 41% New Release
2026-S2-JPMAY-PRI $ 3 32.76 5 23% New Release
2026-S2-JPMAY $ 2 40.01 23 17% New Release
2026-COMCMAY-STRD $ 97.26 4 7% Freshly Listed Sport Cards
2026-BULKJUNE-STRD $ 57.42 58 4% Freshly Listed Bulk Cards
Total $ 1,317.45 91 92%



Released Month SKU Summary
Jan Sales Quantity % of Grand Sales
2026-JPJAN-PA $ 271.92 29 22% NEW RELEASE
2025-JPDEC* $ 260.29 1 21% Semi-New Release
2025-JPNOV-QFBPA $ 164.66 17 13% ETC (older Japanese, cheap holos)
2025-COMCOCT-3MA $ 120.59 14 10% Sport Cards
2025-JPDECP2-QFBPA $ 108.26 1 9% Semi-New Release
Total $ 925.72 62 75%
Mar
2026-S2-JPMAR* $ 260.29 2 19% NEW RELEASE
2026-JPMARP2* $ 226.52 28 17% NEW RELEASE
2026-JPFEB-STRD $ 168.13 5 13% Standard Inventory
2026-JPMARP2 $ 165.00 1 12% NEW RELEASE
2026-* $ 111.26 16 8% ETC (older Japanese, cheap holos)
Total $ 931.20 52 69%

May
2026-S2-JPMAY 456.37 32 38% NEW RELEASE
2026-JPMARP2 200 1 17% Semi-New Release
2026-JPMAY-STRD 107.21 19 9% NEW RELEASE
2026-S3-JPMAR-PRI 90.3 7 8% Semi-New Release
2026-JPMAR-STRD 64.61 7 5% Semi-New Release
Total $ 918.49 66 77%


Conclusions:
- **Even at the end of the month, new releases make up 50-70% of revenue for the month**
- At the start of not new set release months, make up still minimum 60% of revenue. 
- any cards listed 4 months ago are VERY UNLIKELY TO SELL. 

Next Release Consideration
- Measure the lifespan / liquidity of pre-orders/new-set, find a decline age.



