
In this SKU we evaluate our 2026-BULKJUNE as potential to grow profits by investing in bulk cards and selling at a minimum in hopes to compound profits with multiple purchases from buyers. 

Purchase Price
31.12

Quantity 
approximately 200


After a Month of first sale (June 4th)

|                                           |
| ----------------------------------------- |
| Sales Total                               |
| $           85.14                         |
| Quantity Sold: 86                         |
| Marketplace Fees Total                    |
| $    37.46                                |
|                                           |
| Supplies Expense                          |
| $         47.62                           |
|                                           |
| Gross Profit                              |
| $     54.02                               |
|                                           |
| Net Profit                                |
| -$                              31.06     |
|                                           |
| Net Proceeds                              |
| $                               47.68     |
|                                           |
| Capital Recovered                         |
| $                                  >31.12 |
|                                           |
| Active Listings Remaining                 |
| $                           143.55        |
|                                           |
| Buyer Purchase Multiple: 12               |
| Buyer Purchase Multiple Total: 53         |
| AVG. Multiple Total: 4.4                  |
| Total Buyers: 45                          |
| Multi-Purchase Ratio: 26%                 |
|                                           |
|                                           |
|                                           |

Considerations:
- Capital Already Recovered within a month way ahead then expected
- Still around 100$ remaining in inventory 


