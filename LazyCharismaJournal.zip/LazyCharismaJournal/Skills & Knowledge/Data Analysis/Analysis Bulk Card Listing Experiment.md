
- As you may know, I want to list as much cards as possible, and as little effort as possible as well. What I just built is a CSV file with formulas and calculations that would allow me to upload the csv file, and complete 75% of my work. It will even be easier once we learn hosting url of photos, and saving them to a database which is definitely a long-term investment I must make. But let's talk about a specific aspect of the listing process

Process A: simply search the cards you want, and use "Sell Similar Item". Here we get the main database/information of the card (not all of it sometimes)
Process B: to simply input the name, type of card, set, and set/card number, which can be autofilled if we play our cards right.

So let's see a 2-min test for each

Process A: 2-mins = 7 cards
Pros:
- Get price intel, ensure you get the market price right
- can get weeks worth of cards partially ready to list in 5 minutes

Process B 2-Minutes = 7 Cards
Pros: 
- Scalability (auto-photos, auto-price)
- Database 
- Auto-fill increases speed


Suggestions:
- See if you can view condition of cards before hand instead, or just generalize