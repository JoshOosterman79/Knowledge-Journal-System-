
"Japanese Vendors sometimes underestimate the quality of the card. So If I were to spot no damage that would cause the card to be below NM, I can purchase these discounted cards and sell at its full potential price"

Considerations:
- Try Buy It Now, then Auctions
- Trade over Facebook

Key points
- Under Sale the Condition, fully deliver if it's NM
- Below Market Price to attract customers
- Monitor 2x Per Week
- Can we use Pre-Order data (of listed) to determine a sale soon?

2027-07-08
- Today i am actually monitoring what happens if I actually purchase a card from SNKRDUNK, auction the card for small period of time, Purchase ON Bid
- If I fail to sell, I can try Facebook. Which leads me to the Facebook Sales Metric/Project

2026-07-15
- We dive into the data of the listing of consignments of my store. The purpose is to find data/metrics to consider that would predict
- Sales of consignment
- Whether having "in-stock" inventory would sell faster
- Selling outside of eBay, FB, Instagram for example for better margins and marketing 
- To test out out, I went ahead and purchased a Leafeon ex PSA 10 on SNKRDUNK. Here we will see how much it cost (11$ USD) and TAX (7.35 USD). Probably customs/duties as well. The question is if it is worth it If we do bulk shipping instead. We are actually testing the speed time incase I need to make immediate purchases

2027-07-17
- I made Gengar ex as a variation of conditions to test to see if that gets more traffic. Of course I would need to do more research on the card and availability of condition

2026-07-21
- Here I noted the traffic metrics for the 2 consignment items sold

Impressions,eBay views,External views, Quantity sold, Click-through rate, sales conversion rate


Mega Zeraora ex -9,819,21,4,1,0.2%,4.0%, 6 days after listing/re-listing
Mega Gengar ex - 15,797,53,8,1,0.3%,1.6% 4 days after listing/re-listing

I also included something that might be worth checking into which I have noticed lately. Re-listing has something i have done but never really implemented, but I did noticed personally cards selling as quick as 1-week even on some listings that took a while to sell

I also want to note Gengar, originally 520$, was sold at a 8 off from a discount/sale-event. the same day I made a sale event it got sold for around 487

Gengar was also part of a "variation" listing. I would have variations of condition, but also in the future planned for in-stock and their conditions as well. But for now there was only one variation (NM with minor flaws) I wrote

So we make a few theories to test

1) what is the result of 11 pre-order listings if I were to create fresh listings.
2) Do variations listings help?

So we 
- refresh the listings to make them new.

2026-07-25
- So there are two train of thoughts when it comes to the consignment
- Origin data from SNKRDUNK or other platforms
- Consignment / Sales data from store

It would probably be best to start in the origin

2026-07-29
- We discover so far, FromJapan shows cheaper purchasing then directly from SNKRDUNK. Which opens the door for arbitration
- We also can retrieve data to get the price of a certain card of the Lowest Price of a certain Condition on SNKRDUNK




