```
# Goals (May 22 – July 1)

- Make **$500** in profits.
- Lose **3 pounds** (see **212 average**) → **211.1 lbs**
- Connect with **4 new people** _(2 or 10? written beside it)_
- Complete **2 projects** and share on **Resume/LinkedIn**.
- Stick to a schedule of **deep work → low mental tasks → general interest/hobbies**.
- Finish **ICE/Personal Training** course.

---

# Strategies

- For priority, ensure **liquidity is 80% for the month**.
- Consignment services make up an **additional $500 in revenue**.
- Run **3× per week**, gym **2–3× per week**.
- Connect on Facebook, find networking via **run club**, last resort networking events, last resort **Instagram/LinkedIn**.
- Finish bookkeeping system, share, move onto **1× project**.
- Current deep work is **2 hr 30 min**, increase to **3 hrs** by the end of the month. Stick to deep work **off on Thursday and one weekend day**.
- Engage in **30 minutes max** of leisure/interest time after work, increasing to **1 hour** by the end of the month.
- Finish written ICE exam, practice practical aspect by going through **cueing and mock demonstrations**.

---

# Tactics

- Be disciplined with shipping days.
- Have **1–3 revenue/inventory days**.
- **Consignments**.
- Liquidating Facebook listings. If no revenue chances, switch to inventory.
- Gym **Sunday, Thursday** _(try on Tuesday)_.
- Runs **Monday, Wednesday, Saturday**.
- Record progress on run times.
- Hit **5,000 steps every day**. Find time to walk outside without dogs, or **1 dog walk**.
- Network by finding people in the field, offer strengths, receive weaknesses _(or knowledge you don't know)_.
- Study/deep work all but **Thursday & one weekend day (prefer Sunday)**.
- Pick a strict time block—only go outside if **X work is done**.
```

- Make **$500** in profits.
- Seems I made according to my Income Sheet, 250$ in profits, but of course does not take into account the purchases I made in May, which drags it to -800$ Loss.

- Lose **3 pounds** (see **212 average**) 
- Actually see under 212, at around 210-211


- Connect with **4 new people**
- Kinda vague, technically "connected" with 1 person, but also connected with a classroom full of personal trainer students

- Complete **2 projects** and share on **Resume/LinkedIn**.
- None

- Stick to a schedule of **deep work → low mental tasks → general interest/hobbies**.
- Went good, but we can tweak a few things

# Strategies

- For priority, ensure **liquidity is 80% for the month**.

- So unintentionally, I average between the 2 sku's, 80% liqudity
- There's more I learnt on the way, mainly about cash flow and how to distribute, more on that later


- Consignment services make up an **additional $500 in revenue**.

- We did do 1 consignment for over 500$

- Run **3× per week**, gym **2–3× per week**.

- Ran on average 2-3x per week, gym more so 2x, but ramping up to 3x soon. Going to switch 1 run session to a anaerobic biking session



- Connect on Facebook, find networking via **run club**, last resort networking events, last resort **Instagram/LinkedIn**.

- No real efforts to Network


- Finish bookkeeping system, share, move onto **1× project**.

I either over or underdeveloped the idea of a Bookkeeping System, either way, I am still not done it


- Current deep work is **2 hr 30 min**, increase to **3 hrs** by the end of the month. Stick to deep work **off on Thursday and one weekend day**.

Working well, have reached 3 Hours of Deep work. Hoping to move forward from there



- Engage in **30 minutes max** of leisure/interest time after work, increasing to **1 hour** by the end of the month.

Didn't really focused on end of June, did learn to play a bit of the Guitar though



- Finish written ICE exam, practice practical aspect by going through **cueing and mock demonstrations**.

Did not do as well


- Be disciplined with shipping days.
- Shipping a lot is overwhelming, sometimes miss days

- Have **1–3 revenue/inventory days**.
- While I am more aware of what works in terms of Revenue, I feel I don't want to execute unless I know I can sell


- **Consignments**.
- Tried at 5K inventory but no real bitters, would like to investigate and scale




- Liquidating Facebook listings. If no revenue changes, switch to inventory.
I think I mean switch to eBay, haven't really focused on too





- Gym **Sunday, Thursday** _(try on Tuesday)_.
Been going consistently Sunday and Thursday




- Runs **Monday, Wednesday, Saturday**.
Want to do Monday/Wednesday run, and bike Saturday



- Record progress on run times.
I have records, no real goal on how fast I want to run, but aerobic run lasts around 30 minutes now or around 5K




- Hit **5,000 steps every day**. Find time to walk outside without dogs, or **1 dog walk**.
Been hitting, on average, 6,000 steps per day.



- Network by finding people in the field, offer strengths, receive weaknesses _(or knowledge you don't know)_.

Still haven't Network as much as I want to do


- Study/deep work all but **Thursday & one weekend day (prefer Sunday)**.

I think it works pretty well ! Of course I feel I might end up sometimes taking the whole weekend off, which makes me want to put more work on the weekdays If I am going to do that.

- Pick a strict time block—only go outside if **X work is done**.

Have not implement as well, but want to go outside the house more for work instead of trying to work myself to not do things around the house. 



