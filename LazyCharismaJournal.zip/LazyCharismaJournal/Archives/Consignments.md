
The concept is simple.

"To scale the business in a way to not have cash-tied in as little or none at all."

Why do this?
- As someone with ambitions to grow this business, I have struggled to scale the business to what I always wanted. So by building inventory, of inventory I will not purchase until someone does, would allow me to scale in terms of cash-flow, and further increase profits in the long run"

Big Risk
- Lost shipments (and therefore need to purchase once again), although rare, holds a risk still
- Fluctuation of prices (how can I keep cash without buyers cancelling, even technically I still get cash via credit)
- condition/scams, but can be maintained

Big responsibilities
- To update real-time of the estimation of the arrival of cards, needs to be done every Tuesday and Friday I have selected.
- Organized SKU's
- To ensure it covers, or other accounts, covers for shipping costs.

Indirect ways to boost profits/cash-flow
- cashback 
- low interests


Basic Model to follow and scale
- Have a list of cards in mind, and keep in a portfolio of sorts
- List the card in mind, and track it via active-listings, or any sorts. We can then use API data to determine the current market within North America
- We also need to update the arrival dates TUESDAYS and FRIDAYS
- This needs to be my MAIN INCOME for the time being
- ensure proper bookkeeping for consignments


Raw Metrics to go on
- 5,000$ in VALUE
- No more then 50 cards/listings

Hypothetically
- Should more then double your avg sales, numbers

Where does cash go?
- Sales/Capital Return are Re-invested IMMEDIATELY (NO ACCEPTIONS) for June
- Profits go TOWARDS savings until June to decide what to do from there on out

How to source the cards as soon as possible
- Check SNRDUNK, upon purchase, view Rakuma/JDAuctions/Mercari for discounts first.

SNRKDUNK API?


Two Stages of Consignment

Listing

Purchasing

What does a version 1 of this look like?

Listing
- Input of Cards
- Calculations of Cost / Margins to make
- If Passed, List Card
- Monitor Portfolio of Consignments

Purchasing
- Card from Portfolio Sold
- Purchase Window of MAX 24 HRS (
- If found on Mercari at lower end (or discount), purchase
- else: SNKRDUNK
- Await/Ship/Process/Ship to buyer


Tips/Concerns
- Maybe consignment as lots would help?
- Friday = 10% of SNRK Dunk
- Grading Scale

2026-06-11

Sealed Japanese Products
- more niche, less demand, but higher ROI?
- diversity in consignment
- Scarcity in North America as well

Not enough sales
- maybe I was expecting 1 sale?
- Lack of trust
- Incentivize -> Execute -> Build trust from there
- Discounts come to mind
- Better consignment description?


What if you purchased Inventory for insurance, but doesn't sell still
- monitor FB sales
- start IG soon?

Discounts on SNKR 
- seems like every Friday in Japan they host 10% off

PSA/ARS Slabs
"to find amounts high supply from Japan, Low Supply in NA"

Logistics
- 

2026-06-15
- Experimenting with Consignment on Auctions
- Discounted Price, but hoping more increase in sales converted
- Build consignment trust/service


