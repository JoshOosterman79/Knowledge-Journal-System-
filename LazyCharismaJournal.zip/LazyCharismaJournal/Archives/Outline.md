
- metrics to determine
- Removing listing from portfolio
- purchase before sale
- purchase for auction
- purchase for Facebook sale


- Facebook Consignment System as well
- Spreadsheets for facebook consignment for potential buyers to look at

- Your own analysis FIRST before letting algorithms
- 

Phases of the Project
- Phase 1 — Database
- Phase 2 — Data pipeline
- Phase 3 — Analysis
- Phase 4 — Finance
- Phase 5 — Decision science
- Phase 6 — Automation

