
- We will build a program that prints a updated description every run, and can be run on Tuesdays and Friday.
