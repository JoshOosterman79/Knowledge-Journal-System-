
Goal: make 2,000$ in sales that does not rely on Pre-Orders

est. Sales as of 2026-07-13 - 100$

I have my own jargon for selling

Push - Selling what is owed
Pull - Purchasing inventory to convert into Pushes

Methods to make Money (most to least) TOP 5 (Push)
- collect receivable (et 420) - end of month 
- Sell Mega Darkrai EX (et 300) - end of month
- Sealed Pikachu (250) - end of month
- Scott's Cards (100-200) - starting this Friday, end of month
- Investments (100-400$) - prefer not to, but end of month


Field:
- JPFEB (we can bundle these with other cards, so we can try to sell as a collectr Lot)
- Convert Derrick/Basketball Cards to 0.99 free shipping
- AR's 
- Japanese Holos

Pull
- Consignments (200) 
- Adrian (does he want a Gengar?)
- Sport Cards
- Bulk - I need by next week

AR Auctions
- We create two auctions on 2026-07-14 (to end on 2026-07-21)
- We simply took random assorted of cards (mostly aiming at having full arts, and seeing if they sell at a bulk rate)
- ARs - 3$
- V/ex - .75
- Holos - .3
We also lightly record if a new set would encourage a sale
Goal/Objective: To see if it sells a fix price at the end of the month, auction next week would simply be to start at 0.99$ instead

Consignments
- Sell more the Pokémon Products
- Experiment with Variations of Condition


General Structure of Business
- Consignments - Cash/Sales
- Bulk - Profits
- New Set Releases - Cash/Profits
- Sport Cards - Profits

Analysis Projects would include
- Consignments and Liquidity
- Bulk and the % of multiple purchases from buyers
- New Set release revenue/Pre-orders OF THAT set
- Sport Cards and it's profits / time-line

