
- we enter entries in lazy_supplies.txt
- we have a supplies_book found in ebay_orders_project_v1/data (along with inventory books), which imports that txt file
- When we open sales_book to retrieve supplies expense, we are opening supplies_book.

