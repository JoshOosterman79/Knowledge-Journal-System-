- Refer to Orders - SQLLite3 as this will be the file we will use to commit/push to GitHub

- Now that we have that file, we would initiate GitHub within our project folder, and add/commit our database to create version control.

