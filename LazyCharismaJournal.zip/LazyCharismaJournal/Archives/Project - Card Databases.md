
- So before even starting the Card Research Tool, which contains this path

Input Card -> Search through Japan data -> data from Japan -> calculations -> get data from North America -> calculations -> decision-making 


- We want to start off with Input card, but instead of manually having to enter cards into the database (like you do for card research tool, and listing cards). We want a existing database of the card and details, but also an image representing the card. We would then jump into stock photos, instead of having to take photos every time (for smaller/cheaper cards at least)



We would require
- Both a Japanese / English database
- Application that would present you the database, and the photo of the card
- Database integrity that ensures no entry is deleted/updated 


https://pokecabook.com/archives/312825

Here is the source for downloading the set, and notice the data and how it's formatted (the photo from the website)


![[image-1437-6.jpg]]


We get
- set
- set # 
- card #
- card name/pokemon
- type


okay so with those are the only source (the file I shared) that contains in-depth data on the set and it's cards, so If for the time being I want to download new set every month myself, but now I need to find ways to translate the japanese

so my objective would be to translate that page into a csv/txt file of the details, with the katakana, I have a list of the translations to the english name, in which the english name, which would make it easier to put this in a eBay search.

so the objective here is to export this into one row row, and translate them all using a database I have of the katakana 

**So we learn OCR (Optical Character Recognition)**

- Takes hand-written, digital, or documents of text and translate them in machine-encoded text.
- Used for credit card scanning, bank documentation, and data entry fields as well. 
- Is used in cognitive computing, artificial intelligence, and pattern recognition.

In our case, we want to take the document/photo, and translate all the katakana from there into one row, or just one file


Luckily, we have a website doing this for us


https://www.i2ocr.com/free-online-japanese-ocr

we simply paste the image and get a sheet/text of all the text within the image. From there we can paste to a sheet.

Now we have 2 data

- The English-Katakana Pokémon translations
- the Set we want to look at 

Here we created a table with the following columns

Card #	Katakana	Pokemon Name Katakana	Rarity	English Name	Set Name	Set #	Set # of Cards	English Set Name	Full Title (Japanese)	Full Title (English)

So we now create a semi-auto table that gets you a primary ID

- Japanese full name (set/pokemon/card/type)

Which we can translate to english as well

what it lacks
- Images
- scalability if we really want to gather more sets


