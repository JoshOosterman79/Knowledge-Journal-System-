
- When you have pre-orders, we have inconsistent entries for sku and don't know where each listing/card is in each shipment
