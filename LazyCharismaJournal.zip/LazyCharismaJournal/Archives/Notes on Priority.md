
- As someone who is trying to understand more on cash flow and making profits as early as 1-2 month turnover, we must understand currently if our own data suggest what is the next move.

Considerations for Metrics
- Liquidity 
- Margins
- Inventory Remaining
- Priority Held-Up (if in customs/in transit)
- Facebook Liqudity



