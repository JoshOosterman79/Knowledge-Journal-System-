
- Does the SKU tags you give inventory accurately represented within the order data?
- From the Data, your program is able to take manually entered SKU's and there prices, and creates a table representing the SKU, and it's cost
- So in terms of sales, A 1 to 1 (one type of sku/account) gives you the metrics you need to understand capital recovered, profit/loss, and remaining inventory


- We decide to remove duplicates of 
- Username - Order ID - Title

- We now updated the SKU tables to the appropriate Order Table

We also have another issue arising with the sales of SKUs. Noticed for the following

2026-S2-JPMAY*

we have the sales from this SKU, however future sales of SKU's that we simply recycle as (Sell Similar) based on 2026-S2-JPMAY*, would then get sales data for that same SKU once again, instead of what I believe to be more accurate as **per shipment = per SKU**. So we need to adjust by simply overwriting future SKU's (after 2026-S2-JPMAY*) to 2026-S2-JPMAY*


How can we change our system to a per shipment = per SKU?

- Enforce to change SKU during re-stocks, OR
- when uploading via Excel file, simply re-use listings, but change SKU


- If it is not accurate, how can I not only make it accurate, but also considerations/strategies to change the current system to make it accurate.

NEXT TIME: we need to revamp the main sku sales data, as connect the two priority/standard sku tables into 1


- If it is accurate, what is the sales data telling me about the SKU? I want basics of:
- Did I profit/loss from it?
- Do i have any inventory left
- How much capital then I initially invested in, is returned to me.
- Broadly speaking about capital, How much capital, on this date, do i have, that is returned to me, that I can re-distribute to a KNOWN amount of inventory purchased


Remainder: I should subtract chit chats expenses that were actually from spencer's store


Next Time: Revamp the Payables system

The issue with FIFO Payables

- As we increase our payables to supplies or shipping, we noticed that the fixed payment, would cover the new payables. So then we DO have accurate payable amount owed, but we want specific payables and know what we are exactly paying off

So we need to create a system that allows us to specifically pay and record payables owed and have exact amounts paid for SKU, shipment, and supplies

NEXT TIME: we can actually make payables effective by using/manipulating the Dates of each SKU.

- 2026-07-01, we finally completed the Payables Sheet. Here we now know what we owe to each SKU, supplies, and shipping. We can finally now move onto the dashboard to give us what we need to know and execute on 



Dashboard Time

- Now I want to build a simple dashboard that returns me the metrics I want to know. So before designing and having fun with it, I want to get the metrics first of what I need to know

- Based on the Income Statement I made vs the actual downloaded eBay report for June 2026, we include that the Gross Sales via API compared to eBay is off at around 1$ (if we subtract the store subscription from it) and 8.03$ difference in marketplace fees (income statement has 8.03$ greater then the eBay report)

- With a Cash Flow Statement, I have now obtained data of beginning and ending cash along with what we spent cash on (usually inventory and financing it), along with supplies/shipping expenses. From here, we now know the specific sku we paid, and the total amount we paid in inventory.

HW: We need to establish a clean Balance Sheet to ensure Assets = Liabilities

- I also changed the Accounts from TYPE "Credit" to a specific CC (in this case TANG). The Payables book is hard text for TANG. This is fine for now but in case we want to make purchases with other cards, we would need to adjust

HW: IN SKU Priority Data V2, you added the following columns
Quantity Purchased, COGS - Inventory COGS-Import, Column1

finish COGS

- While it's not an issue right now, In the SKU Data Lookup found within the inventory_book "Cost-Standard" is a lump of comc, standard, ebay, and amazon. We would like to standarized / isolate each cost in the future, but for now, it's fine.
- I also would like to be more precise with Investments 
- IN THE Loose SKU Data, for COG/COGS Standard, I may need to find a  more compatible way to get both the COG / COGS based on the sales quantity
- I finally figured out how COGS worked, and is implemented in my sales data and also my income statement. So now its time to work the other side, and see what COG still remains, and if it's listed on my store, what is the markup/listed price
- When it comes to the Budget Sheet (the one that takes in the budget, and the capital returned), I noticed that for capital return we use "Credit" to get the capital returned when inventory was purchased on credit. While this is "good enough" for now, since we branched into specific Credit Accounts we would need to make adjustments later on
- For my investment account, I need to revamp the whole thing after 1.0 release as a lot of transaction involving trades/cash deals have accumulated into me not knowing what is going on. So we assume, we used ALL of the budget of 280$, and we assume we just have all the capital invested into that. Whether now I want to sell investments (which I should) is up to future considerations
- For Supplies in general in the Budget Sheet, I used the numbers that were on the payable, however I need to backtrack my payments so that I want to ensure I don't pay down the supplies if it has already been paid
- We also need to create SKU that is overdue as in the dashboard we are only taking in what's coming up as due
- I might have to make sure that SUMPRODUCT of quantity and Item price is used as Item Price already takes into account the multiple copies / price 

Based on a check, Inventory Book is good now (maybe a little clean up to make it look cleaner)


What are the KPI's to determine SKU (try to find 4-6, assuming I have already due dates

- Priority/Standard Sales 
- Highest Sales of SKU (top-5)
- Highest Gross Profit of SKU (top-5)
- Highest Quantity Sold (top-5)




Future Metrics
- Bulk
- Pre-Orders
- Capital


- For the COGS Table, when we use a SUMIF for the following
2026-*

- We run into 2 issues. One is since this is using * to represent all text/characters afterwards, we cannot get a accurate sales data for 2026-* , therefore we would need to change the SKU

- The Cash Available $ seems to be overestimated right now
- One Universal Slicer?


When Making Mock (therefore cleaning and removing anything unnecessary)
- general inventory sheet
- in inventory sheet, if item price >0, should set ebay fixed fee to .4
- auto-gen SKU
- Cost Priority needs to switch to column "SKU" instead of SKU Specific
- have one book for supplies
- Automated payables (outsourcing what we need to pay)
- for pivot tables, ensure title is above table
- make sure you change your output of mock back to normal afterwards
- Fix orders API to include sales discount as the current does not 
- Need the fixing eBay shipping labels as it replaces data every 90 days
- my cash flow statement takes the sumif of Cash payments when it comes to inventory, but comes from just Inventory Bookkeeping which solely considers only payments of inventory. In the future we may need to change this to consider if we ever pay customs/shipping



