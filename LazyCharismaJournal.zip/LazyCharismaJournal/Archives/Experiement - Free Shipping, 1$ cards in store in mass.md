
With FortAlchemy (on 2026-05-31), I have decided to list 1$ for free shipping to see if it compounds in terms of multiple purchases of these listings. 

Notes
- I listed at flat fee of 1.29$ each card (usually would be around 0.99) as since it came from new set, I don't want to miss out on cards that might be worth 2-3$ 
- I might manually adjust prices on the way to ensure I get most sales optimization
- Spencer's store is Above Standard, we can test vs top-rated seller with my store as well


My Store: 217 Cards were listed at 0.99, free shipping with SKU 2026-BULKJUNE-STRD


