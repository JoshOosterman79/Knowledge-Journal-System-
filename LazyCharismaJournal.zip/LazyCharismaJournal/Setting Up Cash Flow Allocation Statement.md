
1. Understand what programs to run

in ebay_orders_projects_v1, we run the following script within src/ebay

```
py main.py
py PROGRESS_chit-chats.py
py PROGRESS_ebay_shipping_labels.py
py ebay_finances_sku.py
```

Note: soon Main.py will no longer be necessary because we replaced it with ebay_finances_sku, but still run to ensure some computability 


2. Sourcing / Purchasing Data

- ensure all entries for inventory purchases, shipping, and customs are up-to-date for full accuracy. Ensure receipts are downloaded

3. Supplies
- ensure all entries for supplies purchases are up-to-date, and receipts are downloaded



